/*
 * Good Engine - Main Test
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include "../core/good_engine.h"
#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("\n");
    printf("╔════════════════════════════════════════════╗\n");
    printf("║     Good Engine - Stage 1 Test Suite      ║\n");
    printf("║              v0.1.0-alpha                 ║\n");
    printf("║     GNU General Public License v3.0       ║\n");
    printf("╚════════════════════════════════════════════╝\n\n");
    
    /* Test 1: Engine Creation */
    printf("[TEST 1] Engine Creation\n");
    GameEngine *engine = ge_create_engine("TestEngine", 800, 600);
    if (engine) {
        printf("✓ Engine created successfully\n");
    } else {
        printf("✗ Engine creation failed\n");
        return 1;
    }
    printf("\n");
    
    /* Test 2: Scene Creation */
    printf("[TEST 2] Scene Creation\n");
    Scene *scene = ge_create_scene("TestScene");
    if (scene) {
        printf("✓ Scene created successfully\n");
    } else {
        printf("✗ Scene creation failed\n");
        ge_destroy_engine(engine);
        return 1;
    }
    printf("\n");
    
    /* Test 3: GameObject Creation */
    printf("[TEST 3] GameObject Creation\n");
    GameObject *obj1 = ge_create_object("TestObject1", scene);
    GameObject *obj2 = ge_create_object("TestObject2", scene);
    GameObject *obj3 = ge_create_object("TestObject3", scene);
    
    if (obj1 && obj2 && obj3 && scene->objects_count == 3) {
        printf("✓ GameObjects created successfully (Count: %zu)\n", scene->objects_count);
    } else {
        printf("✗ GameObject creation failed\n");
    }
    printf("\n");
    
    /* Test 4: Component System */
    printf("[TEST 4] Component System\n");
    Transform *trans = ge_get_transform(obj1);
    ge_set_position(obj1, 100.0f, 200.0f, 0.0f);
    
    ge_add_sprite(obj1, "assets/test.png");
    Rigidbody *rb = ge_add_rigidbody(obj1, 2.5f);
    Collider *col = ge_add_collider(obj1, COLLIDER_CIRCLE);
    
    if (obj1->components_count == 4) {  /* Transform + Sprite + Rigidbody + Collider */
        printf("✓ Components added successfully (Count: %zu)\n", obj1->components_count);
        printf("  - Position: (%.1f, %.1f, %.1f)\n", trans->x, trans->y, trans->z);
        printf("  - Rigidbody mass: %.1f\n", rb->mass);
        printf("  - Collider shape: Circle\n");
    } else {
        printf("✗ Component system failed\n");
    }
    printf("\n");
    
    /* Test 5: Parent-Child Hierarchy */
    printf("[TEST 5] Parent-Child Hierarchy\n");
    ge_set_object_parent(obj2, obj1);
    ge_set_object_parent(obj3, obj1);
    
    if (obj1->children_count == 2) {
        printf("✓ Parent-child relationship established\n");
        printf("  - Parent: %s, Children: %zu\n", obj1->name, obj1->children_count);
    } else {
        printf("✗ Parent-child relationship failed\n");
    }
    printf("\n");
    
    /* Test 6: Object Management */
    printf("[TEST 6] Object Activity Control\n");
    ge_set_object_active(obj1, false);
    printf("✓ Object activity toggled: %s is now %s\n", 
           obj1->name, obj1->active ? "active" : "inactive");
    ge_set_object_active(obj1, true);
    printf("✓ Object activity toggled: %s is now %s\n", 
           obj1->name, obj1->active ? "active" : "inactive");
    printf("\n");
    
    /* Test 7: Memory Statistics */
    printf("[TEST 7] Memory Management\n");
    ge_memory_stats();
    
    /* Cleanup */
    printf("[CLEANUP] Releasing resources...\n");
    ge_destroy_scene(scene);
    ge_destroy_engine(engine);
    ge_memory_stats();
    
    printf("\n╔════════════════════════════════════════════╗\n");
    printf("║          All tests completed!             ║\n");
    printf("╚════════════════════════════════════════════╝\n\n");
    
    return 0;
}
