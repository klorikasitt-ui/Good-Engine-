# Good Engine - Hızlı Başlangıç Rehberi

**5 dakikada ilk oyununu oluştur!** 🎮

---

## 1. Motor'u Build Et

```bash
# Depoyu klonla
git clone https://github.com/goodengine/goodengine.git
cd "Good engine"

# Build et
mkdir build && cd build
cmake ..
make -j4

# Sonuç
./good_engine_test
```

**Beklenen çıktı:**
```
✓ Engine created successfully
✓ Scene created successfully
✓ GameObjects created successfully (Count: 3)
✓ Components added successfully (Count: 4)
...
```

---

## 2. Basit C Oyunu Oluştur

Yeni dosya: `my_game.c`

```c
#include "core/good_engine.h"

int main() {
    // Motor oluştur
    GameEngine *engine = ge_create_engine("İlk Oyunum", 800, 600);
    ge_set_target_fps(engine, 60.0f);
    
    // Sahne oluştur
    Scene *scene = ge_create_scene("MainLevel");
    
    // Oyuncu oluştur
    GameObject *player = ge_create_object("Player", scene);
    ge_set_position(player, 400.0f, 300.0f, 0.0f);
    
    // Bileşenler ekle
    ge_add_sprite(player, "assets/player.png");
    ge_add_rigidbody(player, 1.0f);
    ge_add_collider(player, COLLIDER_BOX);
    
    ge_log(GE_LOG_INFO, "Oyun başladı!");
    
    // Oyunu çalıştır
    ge_run(engine, scene);
    
    // Temizle
    ge_destroy_scene(scene);
    ge_destroy_engine(engine);
    
    return 0;
}
```

**Derle ve çalıştır:**
```bash
gcc -I. my_game.c -L./build -lgood_engine -o my_game
./my_game
```

---

## 3. Python ile Oyun Oluştur

Yeni dosya: `my_game.py`

```python
from scripting.python.good_engine import (
    GameEngine, Scene, GameObject, 
    ColliderShape, LogLevel, log
)

# Motor oluştur
engine = GameEngine("PyGame", 800, 600)

# Sahne oluştur
scene = Scene("MainScene")

# Oyuncu oluştur
player = GameObject("Player", scene)
player.set_position(400, 300, 0)

# Bileşenler ekle
player.add_sprite("assets/player.png")
player.add_rigidbody(mass=1.0)
player.add_collider(ColliderShape.BOX)

log(LogLevel.INFO, "Python oyun başladı!")
print("Hazır!")
```

**Çalıştır:**
```bash
cd scripting/python
python3 my_game.py
```

---

## 4. Proje Yapısını Anla

```
Good engine/
├── core/              → Motor çekirdeği (C)
├── physics/           → Fizik (gelecek)
├── graphics/          → Grafik (gelecek)
├── scripting/         → Programlama dilleri
│   └── python/        → Python bridge
├── docs/              → Dokümantasyon
│   ├── API.md         ← API referansı
│   ├── BUILD.md       ← Build rehberi
│   └── SCRIPTING.md   ← Python rehberi
└── tests/             → Test dosyaları
```

---

## 5. Sonraki Adımlar

### Daha Fazla Öğren
- 📖 [API Referansı](docs/API.md) - Tüm fonksiyonlar
- 🐍 [Python Rehberi](docs/SCRIPTING.md) - Python örnekleri
- 🔧 [Build Rehberi](docs/BUILD.md) - Kurulum & sorun giderme

### Örnek Oyunlar
```bash
# Android için build
mkdir build-android && cd build-android
cmake .. -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.cmake
make
```

### Katkıda Bulun
1. Fork et: https://github.com/goodengine/goodengine
2. Feature branch oluştur: `git checkout -b feature/MyFeature`
3. Commit et: `git commit -am 'Add MyFeature'`
4. Push et: `git push origin feature/MyFeature`
5. Pull Request aç!

---

## Yaygın Sorunlar

### Sorun: "libgood_engine.so bulunamıyor"
```bash
# Motor'u build ettiniz mi?
cd build && cmake .. && make
# Veya path'i ayarlayın
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$(pwd)/build
```

### Sorun: CMake hatası
```bash
# CMake kurduğunuz mu?
cmake --version  # 3.16+ olmalı

# Linux'ta
sudo apt-get install cmake

# macOS'ta
brew install cmake
```

### Sorun: Python bridge ImportError
```bash
# Libgood_engine.so'yu Python dizinine kopyalayın
cp build/libgood_engine.so scripting/python/
cd scripting/python
python3 good_engine.py
```

---

## Docslar Nerede?

| İhtiyacınız | Gidecek Yer |
|-----------|-----------|
| C API | `docs/API.md` |
| Python scripting | `docs/SCRIPTING.md` |
| Build setup | `docs/BUILD.md` |
| Proje yapısı | `STRUCTURE.md` |

---

## Motor Özellikleri

✅ **Stage 1 (Mevcut)**
- GameObject & Component sistemi
- Transform, Sprite, Rigidbody, Collider
- Python bridge
- C API

⏳ **Stage 2 (Yakında)**
- Physics engine (Bullet)
- Graphics (OpenGL ES / Vulkan)
- Audio sistemi

📅 **Stage 3+**
- Scene editor
- Plugin sistemi
- Rust/Go/Brainfuck support

---

## Komünite

- 🐛 Hataları bildir: [Issues](https://github.com/goodengine/goodengine/issues)
- 💬 Tartış: [Discussions](https://github.com/goodengine/goodengine/discussions)
- 📧 İletişim: contact@goodengine.dev (kurulunca)

---

## Lisans

GNU General Public License v3.0

Herhangi bir kısıtlama olmaksızın özgürce kullan, değiştir ve dağıt!

---

**Keyifli oyun geliştirmeyi!** 🚀

Sorular? Issues açın veya Discussions'da soru sorun!
