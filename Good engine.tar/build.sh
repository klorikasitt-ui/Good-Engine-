#!/bin/bash
# Good Engine - Build & Test Script
# Usage: ./build.sh [desktop|android|test|clean]

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${PROJECT_DIR}/build"
BUILD_ANDROID_DIR="${PROJECT_DIR}/build-android"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_header() {
    echo -e "${GREEN}"
    echo "╔════════════════════════════════════════════╗"
    echo "║       Good Engine Build & Test Script      ║"
    echo "║              v0.1.0-alpha                 ║"
    echo "╚════════════════════════════════════════════╝"
    echo -e "${NC}"
}

build_desktop() {
    echo -e "${YELLOW}Building for Desktop (Linux/macOS)...${NC}"
    
    if [ ! -d "$BUILD_DIR" ]; then
        mkdir -p "$BUILD_DIR"
    fi
    
    cd "$BUILD_DIR"
    cmake .. -DCMAKE_BUILD_TYPE=Release
    make -j$(nproc)
    
    echo -e "${GREEN}✓ Desktop build successful!${NC}"
    echo "  Binary: $BUILD_DIR/good_engine_test"
    echo "  Library: $BUILD_DIR/libgood_engine.so"
}

build_android() {
    echo -e "${YELLOW}Building for Android NDK...${NC}"
    
    if [ -z "$ANDROID_NDK" ]; then
        echo -e "${RED}✗ ANDROID_NDK not set!${NC}"
        echo "Set it with: export ANDROID_NDK=/path/to/ndk"
        return 1
    fi
    
    if [ ! -d "$BUILD_ANDROID_DIR" ]; then
        mkdir -p "$BUILD_ANDROID_DIR"
    fi
    
    cd "$BUILD_ANDROID_DIR"
    cmake .. \
        -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.cmake \
        -DANDROID_PLATFORM=android-21 \
        -DANDROID_ABI=arm64-v8a \
        -DCMAKE_BUILD_TYPE=Release
    make -j$(nproc)
    
    echo -e "${GREEN}✓ Android build successful!${NC}"
    echo "  Library: $BUILD_ANDROID_DIR/libgood_engine.so"
}

run_test() {
    echo -e "${YELLOW}Running tests...${NC}"
    
    if [ ! -f "$BUILD_DIR/good_engine_test" ]; then
        echo -e "${RED}✗ Test binary not found!${NC}"
        echo "  Build first: ./build.sh desktop"
        return 1
    fi
    
    cd "$BUILD_DIR"
    ./good_engine_test
    
    echo -e "${GREEN}✓ Tests completed!${NC}"
}

clean() {
    echo -e "${YELLOW}Cleaning build directories...${NC}"
    
    rm -rf "$BUILD_DIR"
    rm -rf "$BUILD_ANDROID_DIR"
    
    echo -e "${GREEN}✓ Cleaned!${NC}"
}

print_help() {
    echo "Usage: ./build.sh [command]"
    echo ""
    echo "Commands:"
    echo "  desktop       Build for Linux/macOS (default)"
    echo "  android       Build for Android NDK"
    echo "  test          Run test suite"
    echo "  clean         Clean build artifacts"
    echo "  help          Show this help"
    echo ""
    echo "Environment Variables:"
    echo "  ANDROID_NDK   Path to Android NDK (required for android build)"
    echo ""
    echo "Examples:"
    echo "  ./build.sh                    # Build for desktop"
    echo "  ./build.sh test               # Build and run tests"
    echo "  ANDROID_NDK=/ndk ./build.sh android  # Build for Android"
}

# Main script
print_header

case "${1:-desktop}" in
    desktop)
        build_desktop
        ;;
    android)
        build_android
        ;;
    test)
        build_desktop
        run_test
        ;;
    clean)
        clean
        ;;
    help|--help|-h)
        print_help
        ;;
    *)
        echo -e "${RED}Unknown command: $1${NC}"
        print_help
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}Done!${NC}"
