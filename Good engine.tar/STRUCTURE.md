# Good Engine - Proje Yapısı

## Dizin Ağacı

```
Good engine/
│
├── 📄 README.md                    # Proje ana dökümanı
├── 📄 LICENSE                      # GNU General Public License v3.0
├── 📄 CMakeLists.txt              # CMake build konfigürasyonu
├── 📄 build.gradle                # Android Gradle build
├── 📄 STRUCTURE.md                # Bu dosya
│
├── 📁 core/                        # Motor çekirdeği (C)
│   ├── good_engine.h              # Ana başlık dosyası (PUBLIC API)
│   ├── memory_manager.h           # Bellek yönetimi
│   ├── memory_manager.c
│   ├── game_loop.c                # Ana oyun döngüsü (3000+ satır)
│   ├── resource_manager.c         # Kaynak yönetimi (TODO)
│   ├── event_system.c             # Olay sistemi (TODO)
│   ├── game_object.c              # GameObject (game_loop.c'de)
│   ├── scene.c                    # Scene (game_loop.c'de)
│   └── component.c                # Component (game_loop.c'de)
│
├── 📁 physics/                     # Fizik motoru
│   ├── physics_world.c            # Fizik dünyası (TODO)
│   ├── rigidbody.c                # Rigidbody (TODO)
│   └── collider.c                 # Collider (TODO)
│
├── 📁 graphics/                    # Grafik sistemi
│   ├── renderer.c                 # Vulkan/OpenGL ES renderer (TODO)
│   ├── texture_loader.c           # Texture loading (TODO)
│   └── shader_compiler.c          # Shader compiler (TODO)
│
├── 📁 plugins/                     # Plugin sistemi
│   ├── plugin_interface.h         # Plugin API (TODO)
│   ├── plugin_loader.c            # Plugin yükleme (TODO)
│   └── plugin_manager.c           # Plugin yönetimi (TODO)
│
├── 📁 scripting/                   # Scripting sistemleri
│   ├── common/
│   │   └── scripting.h            # Ortak scripting arayüzü
│   ├── python/
│   │   └── good_engine.py         # Python bridge (ctypes FFI)
│   ├── rust/                      # Rust FFI (Stage 3)
│   ├── go/                        # Go bindings (Stage 3)
│   └── brainfuck/                 # Brainfuck interpreter (Stage 3)
│
├── 📁 tools/                       # Geliştirici araçları
│   ├── editor/                    # GUI editör (Stage 3)
│   ├── asset_tools/               # Asset işleme araçları
│   └── build_tools/               # Build script'leri
│
├── 📁 assets/                      # Varsayılan varlık kütüphanesi
│   ├── models/                    # 3D modeller (glTF)
│   ├── textures/                  # Doku dosyaları (PNG, etc)
│   ├── sounds/                    # Ses dosyaları (OGG)
│   └── prefabs/                   # Hazır nesneler (JSON)
│
├── 📁 tests/                       # Test dosyaları
│   └── main_test.c                # Ana test suite
│
├── 📁 docs/                        # Dokümantasyon
│   ├── API.md                     # C API Referansı
│   ├── BUILD.md                   # Build & Kurulum Rehberi
│   ├── SCRIPTING.md               # Python Scripting Rehberi
│   ├── PHYSICS.md                 # Fizik Sistemi (TODO)
│   ├── PLUGINS.md                 # Plugin Geliştirme (TODO)
│   └── CONTRIBUTING.md            # Katkıda Bulunma (TODO)
│
├── 📁 build/                       # Build çıktıları (git ignored)
│   ├── libgood_engine.so
│   ├── good_engine_test
│   └── ...
│
└── 📁 build-android/              # Android build çıktıları (git ignored)
    ├── libgood_engine.so
    └── ...
```

---

## Dosya Açıklamaları

### Core Engine (core/)

| Dosya | Satır | Amaç |
|-------|-------|------|
| `good_engine.h` | 250+ | Tüm public API fonksiyonları ve struct'ları |
| `memory_manager.c` | 150+ | Bellek ayırma, boşaltma ve istatistikler |
| `game_loop.c` | 800+ | Motor ana döngüsü, GameObject, Component, Scene |
| `resource_manager.c` | 50+ | Kaynak yönetimi (TODO) |
| `event_system.c` | 50+ | Olay sistemi (TODO) |

### Physics (physics/)

| Dosya | Amaç |
|-------|------|
| `physics_world.c` | Bullet/Rapier entegrasyonu |
| `rigidbody.c` | Katı cisim fiziği |
| `collider.c` | Çarpışma algılaması |

### Graphics (graphics/)

| Dosya | Amaç |
|-------|------|
| `renderer.c` | Vulkan/OpenGL ES render pipeline |
| `texture_loader.c` | PNG/JPG/glTF yükleme |
| `shader_compiler.c` | GLSL → SPIR-V derleyicisi |

### Scripting (scripting/)

| Dosya | Dil | Tamamlama |
|-------|-----|-----------|
| `python/good_engine.py` | Python | ✓ Stage 1 |
| `rust/` | Rust | Stage 3 |
| `go/` | Go | Stage 3 |
| `brainfuck/` | Brainfuck | Stage 3 |

### Documentation (docs/)

| Dosya | İçerik |
|-------|--------|
| `API.md` | C API fonksiyonlarının detaylı açıklaması |
| `BUILD.md` | Kurulum, build ve sorun giderme |
| `SCRIPTING.md` | Python bridge kullanımı ve örnekler |
| `PHYSICS.md` | Fizik motoru rehberi (gelecek) |
| `PLUGINS.md` | Plugin geliştirme (gelecek) |

---

## Build Artifacts (Git Ignored)

Derlemeden sonra bu dosyalar oluşturulur:

```
build/
├── libgood_engine.so       # Paylaşılan kütüphane
├── good_engine_test        # Test çalıştırılabilir
├── CMakeFiles/
├── cmake_install.cmake
└── Makefile

build-android/
├── libgood_engine.so       # Android NDK library
├── CMakeFiles/
└── ...
```

---

## Dosya Boyutları (Stage 1)

```
core/good_engine.h ............... ~250 satır
core/game_loop.c .............. ~800 satır
core/memory_manager.c ......... ~150 satır
scripting/python/good_engine.py .. ~350 satır
docs/API.md .................... ~350 satır
docs/BUILD.md .................. ~200 satır
docs/SCRIPTING.md .............. ~300 satır
tests/main_test.c ............... ~100 satır
────────────────────────────────────────
TOPLAM (Stage 1) ........... ~2,500 satır
```

---

## Geliştirme Yol Haritası

### ✅ Stage 1: Foundation (Tamamlandı)
- [x] Temel C motor çekirdeği
- [x] GameObject ve Component sistemi
- [x] Transform, Sprite, Rigidbody, Collider
- [x] Python bridge
- [x] Memory management
- [x] Test suite
- [x] Dokümantasyon

### 🔄 Stage 2: Physics & Graphics (Devamında)
- [ ] Bullet Physics entegrasyonu
- [ ] OpenGL ES / Vulkan renderer
- [ ] Texture loading (glTF, PNG)
- [ ] Scene serialization
- [ ] Audio sistem

### 📋 Stage 3: GUI & Tools (Planlanmış)
- [ ] Basit GUI framework
- [ ] Scene editor
- [ ] Rust FFI
- [ ] Go bindings
- [ ] Brainfuck interpreter

### 🎯 Stage 4: Plugins & Languages (Planlanmış)
- [ ] Plugin loader sistemi
- [ ] Plugin marketplace
- [ ] Mod support
- [ ] Debugging tools

### 🎨 Stage 5: Content (Planlanmış)
- [ ] Model kütüphanesi
- [ ] Animation sistemi
- [ ] Example games
- [ ] Content pipeline

---

## Lisans Yapısı

Tüm dosyalarda GPL v3 header bulunur:

```c
/*
 * Good Engine - [Bileşen Adı]
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */
```

---

## Katkı Kuralları

1. Tüm yeni dosyalara GPL v3 header ekleyin
2. API fonksiyonlarını `good_engine.h`'de tanımlayın
3. Test yazın (`tests/` klasöründe)
4. Dokümantasyon güncelleyin (`docs/` klasöründe)
5. CMakeLists.txt'yi güncelleyin

---

**Oluşturuldu:** Nisan 2026  
**Sürüm:** 0.1.0-alpha  
**Durum:** Aktif Geliştirme
