/*
 * Good Engine - Renderer
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_renderer_init() {
    printf("[INFO] Renderer initialized (Vulkan/OpenGL ES)\n");
}

void ge_renderer_cleanup() {
    printf("[INFO] Renderer cleaned up\n");
}
