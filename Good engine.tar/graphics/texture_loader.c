/*
 * Good Engine - Texture Loader
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_texture_loader_init() {
    printf("[INFO] Texture Loader initialized\n");
}

void ge_texture_loader_cleanup() {
    printf("[INFO] Texture Loader cleaned up\n");
}
