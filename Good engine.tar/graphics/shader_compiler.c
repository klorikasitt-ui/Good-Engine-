/*
 * Good Engine - Shader Compiler
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_shader_compiler_init() {
    printf("[INFO] Shader Compiler initialized (GLSL/SPIR-V)\n");
}

void ge_shader_compiler_cleanup() {
    printf("[INFO] Shader Compiler cleaned up\n");
}
