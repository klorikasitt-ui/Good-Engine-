# Good Engine - Changelog

Tüm önemli değişiklikler bu dosyada belgelenmiştir.

Formatting follows the guidelines from [Keep a Changelog](https://keepachangelog.com/).

---

## [0.1.0-alpha] - 2026-04-17

### Added (Stage 1 Foundation)

#### Core Engine
- ✨ Game loop implementation with configurable FPS
- ✨ Memory management system (malloc, calloc, realloc, free tracking)
- ✨ GameObject and Component architecture
- ✨ Transform component (position, rotation, scale)
- ✨ Sprite component for rendering
- ✨ Rigidbody component for basic physics properties
- ✨ Collider component with multiple shape support (Circle, Box, Polygon, Capsule)
- ✨ Scene management system
- ✨ Parent-child object hierarchy
- ✨ Comprehensive logging system (DEBUG, INFO, WARNING, ERROR levels)

#### Scripting
- ✨ Python bridge using ctypes FFI
- ✨ Full API bindings for Python
- ✨ Example Python game scripts
- ✨ Component type enumerations for Python

#### Tools
- ✨ CMake build system for Linux/macOS/Android
- ✨ Android NDK integration
- ✨ Gradle build configuration
- ✨ Comprehensive test suite
- ✨ Build script (build.sh)

#### Documentation
- ✨ API Reference (docs/API.md)
- ✨ Build & Installation Guide (docs/BUILD.md)
- ✨ Python Scripting Guide (docs/SCRIPTING.md)
- ✨ Quick Start Guide (QUICKSTART.md)
- ✨ Contributing Guide (CONTRIBUTING.md)
- ✨ Project Structure (STRUCTURE.md)

#### Licensing
- ✨ GNU General Public License v3.0
- ✨ GPL headers in all source files

### Changed
- N/A (Initial release)

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- N/A

### Security
- ✨ Memory leak detection in memory manager
- ✨ Bounds checking in dynamic arrays

---

## [0.0.0] - 2026-04-01

### Added
- 📋 Project initialization
- 📋 Repository setup
- 📋 Planning documents
- 📋 Development roadmap

---

## Upcoming

### Stage 2: Physics & Graphics [ETA: May 2026]
- [ ] Physics engine integration (Bullet Physics / Rapier)
- [ ] 2D rigid body dynamics
- [ ] Collision detection and response
- [ ] Graphics rendering (Vulkan/OpenGL ES)
- [ ] Texture loading (PNG, glTF)
- [ ] Sprite rendering and batching
- [ ] Audio system
- [ ] Scene serialization

### Stage 3: GUI & Tools [ETA: June 2026]
- [ ] Minimal GUI framework
- [ ] Scene editor
- [ ] Property inspector
- [ ] Asset browser
- [ ] Rust FFI integration
- [ ] Go language bindings
- [ ] Brainfuck interpreter

### Stage 4: Plugins & Community [ETA: July 2026]
- [ ] Plugin loader system
- [ ] Plugin manager
- [ ] Plugin marketplace structure
- [ ] Mod support with sandboxing
- [ ] Permission system
- [ ] Debugging and profiling tools

### Stage 5: Content & Community [ETA: August 2026]
- [ ] Model library (3D models, sprites)
- [ ] Animation system (skeletal, sprite sheets)
- [ ] Example games
- [ ] Content pipeline tools
- [ ] Community templates

---

## Version Numbers

Good Engine uses semantic versioning: `MAJOR.MINOR.PATCH[-SUFFIX]`

- `0.1.0-alpha`: Alpha release (Stage 1)
- `0.2.0-beta`: Beta release (Stage 2)
- `0.3.0-rc`: Release candidate (Stage 3)
- `1.0.0`: First stable release

---

## How to Update

Users can track progress by watching this repository and checking:
- 📊 [Milestones](https://github.com/goodengine/goodengine/milestones)
- 📝 [Releases](https://github.com/goodengine/goodengine/releases)
- 🗨️ [Discussions](https://github.com/goodengine/goodengine/discussions)

---

## Versioning Policy

- **Major (0→1)**: Stable API, backwards compatibility
- **Minor (→2)**: New features, backwards compatible
- **Patch (→0.1.1)**: Bug fixes, security updates
- **Pre-release (-alpha/-beta)**: Experimental versions

---

**Last Updated:** April 17, 2026  
**Maintained by:** Good Engine Contributors  
**License:** GNU General Public License v3.0
