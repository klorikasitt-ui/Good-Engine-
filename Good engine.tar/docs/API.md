# Good Engine - API Referansı

## Giriş

Good Engine C API'si, güçlü bir oyun motoru inşa etmek için temel fonksiyonlar sağlar. Bu belgede tüm ana API fonksiyonları açıklanmıştır.

## İçindekiler

1. [Engine Yönetimi](#engine-yönetimi)
2. [Scene Yönetimi](#scene-yönetimi)
3. [GameObject Yönetimi](#gameobject-yönetimi)
4. [Component Sistemi](#component-sistemi)
5. [Transform İşlemleri](#transform-işlemleri)
6. [Sprite İşlemleri](#sprite-işlemleri)
7. [Fizik (Rigidbody & Collider)](#fizik-rigidbody--collider)
8. [Logging](#logging)

---

## Engine Yönetimi

### ge_create_engine()
Motor örneği oluşturur.

```c
GameEngine* ge_create_engine(const char *name, uint32_t width, uint32_t height);
```

**Parametreler:**
- `name`: Motor adı
- `width`: Ekran genişliği (piksel)
- `height`: Ekran yüksekliği (piksel)

**Dönüş:**
- Başarı: `GameEngine*` işaretçisi
- Hata: `NULL`

**Örnek:**
```c
GameEngine *engine = ge_create_engine("MyGame", 1280, 720);
```

---

### ge_destroy_engine()
Motor örneğini yok eder.

```c
void ge_destroy_engine(GameEngine *engine);
```

**Parametreler:**
- `engine`: Yok edilecek motor

**Örnek:**
```c
ge_destroy_engine(engine);
```

---

### ge_set_target_fps()
Motor hedef FPS'sini ayarlar.

```c
void ge_set_target_fps(GameEngine *engine, float fps);
```

**Parametreler:**
- `engine`: Motor örneği
- `fps`: Hedef FPS (örn: 60.0, 120.0)

**Örnek:**
```c
ge_set_target_fps(engine, 60.0f);
```

---

## Scene Yönetimi

### ge_create_scene()
Yeni bir sahne oluşturur.

```c
Scene* ge_create_scene(const char *name);
```

**Parametreler:**
- `name`: Sahne adı

**Dönüş:**
- Başarı: `Scene*` işaretçisi
- Hata: `NULL`

**Örnek:**
```c
Scene *scene = ge_create_scene("Level1");
```

---

### ge_destroy_scene()
Sahneyi yok eder.

```c
void ge_destroy_scene(Scene *scene);
```

---

### ge_load_scene()
Sahneyi yükler (etkinleştirir).

```c
void ge_load_scene(Scene *scene);
```

---

### ge_unload_scene()
Sahneyi boşaltır (devre dışı bırakır).

```c
void ge_unload_scene(Scene *scene);
```

---

## GameObject Yönetimi

### ge_create_object()
Yeni bir oyun nesnesi oluşturur.

```c
GameObject* ge_create_object(const char *name, Scene *scene);
```

**Parametreler:**
- `name`: Nesne adı
- `scene`: Nesnenin ekleneceği sahne

**Dönüş:**
- `GameObject*` işaretçisi

**Örnek:**
```c
GameObject *player = ge_create_object("Player", scene);
```

---

### ge_destroy_object()
Oyun nesnesini yok eder.

```c
void ge_destroy_object(GameObject *object);
```

---

### ge_set_object_active()
Nesneyi aktif/inaktif yapar.

```c
void ge_set_object_active(GameObject *object, bool active);
```

**Örnek:**
```c
ge_set_object_active(player, true);   // Aktif
ge_set_object_active(player, false);  // İnaktif
```

---

### ge_set_object_parent()
Nesneye bir parent ayarlar (hiyerarşi).

```c
void ge_set_object_parent(GameObject *child, GameObject *parent);
```

**Örnek:**
```c
ge_set_object_parent(arm, player);  // arm, player'ın çocuğu
```

---

## Component Sistemi

### ge_add_component()
Nesneye component ekler.

```c
Component* ge_add_component(GameObject *object, ComponentType type);
```

**Parametreler:**
- `object`: Hedef nesne
- `type`: Component türü (COMPONENT_TRANSFORM, COMPONENT_SPRITE, vb.)

**Örnek:**
```c
Sprite *sprite = ge_add_sprite(obj, "assets/player.png");
Rigidbody *rb = ge_add_rigidbody(obj, 1.0f);
Collider *col = ge_add_collider(obj, COLLIDER_BOX);
```

---

### ge_get_component()
Nesneden component alır.

```c
Component* ge_get_component(GameObject *object, ComponentType type);
```

---

### ge_remove_component()
Nesneden component kaldırır.

```c
void ge_remove_component(GameObject *object, ComponentType type);
```

---

## Transform İşlemleri

### ge_get_transform()
Transform component'ini alır.

```c
Transform* ge_get_transform(GameObject *object);
```

---

### ge_set_position()
Nesnenin konumunu ayarlar.

```c
void ge_set_position(GameObject *object, float x, float y, float z);
```

**Örnek:**
```c
ge_set_position(player, 100.0f, 200.0f, 0.0f);
```

---

### ge_set_rotation()
Nesnenin rotasyonunu ayarlar (derece cinsinden).

```c
void ge_set_rotation(GameObject *object, float x, float y, float z);
```

---

### ge_set_scale()
Nesnenin ölçeğini ayarlar.

```c
void ge_set_scale(GameObject *object, float x, float y, float z);
```

---

## Sprite İşlemleri

### ge_add_sprite()
Nesneye Sprite component ekler.

```c
Sprite* ge_add_sprite(GameObject *object, const char *texture_path);
```

**Parametreler:**
- `object`: Hedef nesne
- `texture_path`: Texture dosya yolu

**Örnek:**
```c
ge_add_sprite(player, "assets/player.png");
```

---

### ge_set_sprite_layer()
Sprite'ın katman sırasını ayarlar.

```c
void ge_set_sprite_layer(GameObject *object, float layer);
```

---

## Fizik (Rigidbody & Collider)

### ge_add_rigidbody()
Nesneye Rigidbody ekler.

```c
Rigidbody* ge_add_rigidbody(GameObject *object, float mass);
```

**Parametreler:**
- `object`: Hedef nesne
- `mass`: Kütle (kg cinsinden)

**Örnek:**
```c
ge_add_rigidbody(player, 1.0f);
```

---

### ge_set_rigidbody_velocity()
Rigidbody'nin hızını ayarlar.

```c
void ge_set_rigidbody_velocity(GameObject *object, float vx, float vy);
```

---

### ge_set_rigidbody_gravity_scale()
Rigidbody'nin yerçekimi ölçeğini ayarlar.

```c
void ge_set_rigidbody_gravity_scale(GameObject *object, float scale);
```

---

### ge_add_collider()
Nesneye Collider ekler.

```c
Collider* ge_add_collider(GameObject *object, ColliderShape shape);
```

**ColliderShape Türleri:**
- `COLLIDER_CIRCLE`: Daire şekli
- `COLLIDER_BOX`: Kutu şekli
- `COLLIDER_POLYGON`: Çokgen şekli
- `COLLIDER_CAPSULE`: Kapsül şekli

**Örnek:**
```c
ge_add_collider(player, COLLIDER_BOX);
```

---

### ge_set_collider_size()
Collider boyutlarını ayarlar.

```c
void ge_set_collider_size(GameObject *object, float width, float height);
```

---

### ge_set_collider_trigger()
Collider'ı tetikleyici olarak ayarlar.

```c
void ge_set_collider_trigger(GameObject *object, bool is_trigger);
```

---

## Logging

### ge_log()
Mesaj kaydeder.

```c
void ge_log(LogLevel level, const char *format, ...);
```

**LogLevel Türleri:**
- `GE_LOG_DEBUG`: Debug mesajı
- `GE_LOG_INFO`: Bilgi mesajı
- `GE_LOG_WARNING`: Uyarı mesajı
- `GE_LOG_ERROR`: Hata mesajı

**Örnek:**
```c
ge_log(GE_LOG_INFO, "Player created at (%.1f, %.1f)", x, y);
ge_log(GE_LOG_ERROR, "Failed to load texture: %s", filename);
```

---

## Bellek Yönetimi

### ge_malloc(), ge_calloc(), ge_realloc(), ge_free()
Bellek ayırma/boşaltma fonksiyonları.

```c
void* ge_malloc(size_t size);
void* ge_calloc(size_t count, size_t size);
void* ge_realloc(void *ptr, size_t size);
void ge_free(void *ptr);
```

---

### ge_memory_stats()
Bellek istatistiklerini yazdırır.

```c
void ge_memory_stats();
```

---

## Tam Örnek

```c
#include "good_engine.h"

int main() {
    // Motor oluştur
    GameEngine *engine = ge_create_engine("MyGame", 1280, 720);
    ge_set_target_fps(engine, 60.0f);
    
    // Sahne oluştur
    Scene *scene = ge_create_scene("MainLevel");
    
    // Oyuncu nesnesi oluştur
    GameObject *player = ge_create_object("Player", scene);
    ge_set_position(player, 640.0f, 360.0f, 0.0f);
    
    // Component'ler ekle
    ge_add_sprite(player, "assets/player.png");
    Rigidbody *rb = ge_add_rigidbody(player, 1.0f);
    Collider *col = ge_add_collider(player, COLLIDER_BOX);
    ge_set_collider_size(player, 64.0f, 64.0f);
    
    ge_log(GE_LOG_INFO, "Game initialized!");
    
    // Oyunu çalıştır
    ge_run(engine, scene);
    
    // Temizle
    ge_destroy_scene(scene);
    ge_destroy_engine(engine);
    
    return 0;
}
```

---

**Son Güncelleme:** Nisan 2026  
**Sürüm:** 0.1.0-alpha  
**Lisans:** GNU General Public License v3.0
