# Good Engine - Kurulum & Build Rehberi

## Sistem Gereksinimleri

### Minimal Gereksinimler
- **OS**: Linux, macOS, Windows 10+
- **RAM**: 2GB
- **Disk**: 1GB boş alan

### Geliştirme Ortamı

#### Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install -y \
    build-essential \
    cmake \
    git \
    python3 \
    python3-dev
```

#### macOS
```bash
# Xcode Command Line Tools
xcode-select --install

# Homebrew paketleri
brew install cmake python3
```

#### Windows
- Visual Studio 2019+ veya MinGW GCC
- CMake 3.16+
- Python 3.8+

---

## Android Geliştirme Kurulumu

### 1. Android NDK İndir

```bash
# Android Studio üzerinden:
# Preferences > Appearance & Behavior > System Settings > Android SDK
# SDK Tools > NDK (Side by side) seçiniz

# Veya manuel indirme:
wget https://dl.google.com/android/repository/android-ndk-r21e-linux-x86_64.zip
unzip android-ndk-r21e-linux-x86_64.zip
```

### 2. Çevre Değişkenlerini Ayarla

```bash
# ~/.bashrc veya ~/.zshrc içine ekle:
export ANDROID_NDK=/path/to/android-ndk-r21e
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_NDK

# Değişiklikleri uygula:
source ~/.bashrc
```

### 3. Android için Build Yapma

```bash
mkdir build-android
cd build-android

cmake .. \
    -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.cmake \
    -DANDROID_PLATFORM=android-21 \
    -DANDROID_ABI=arm64-v8a \
    -DCMAKE_BUILD_TYPE=Release

make -j4
```

---

## Desktop (Linux/macOS) Build

### Basit Build
```bash
mkdir build
cd build
cmake ..
make -j4

# Test çalıştır
./good_engine_test
```

### Detaylı Build
```bash
mkdir build
cd build

# Debug modu ile
cmake .. -DCMAKE_BUILD_TYPE=Debug
make -j4
./good_engine_test

# Release modu ile
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j4 -s
```

### Kurulum
```bash
sudo make install

# Kontrol et
pkg-config --cflags good_engine
```

---

## Python Bridge Kurulumu

### Gereksinimler
```bash
# Linux
sudo apt-get install python3-dev libpython3-dev

# macOS
brew install python3
```

### Build
```bash
cd scripting/python

# Motor kütüphanesini bul
find ../../build -name "libgood_engine.so" -o -name "libgood_engine.dylib"

# Python script'i kullan
python3 good_engine.py
```

### Örnek Kullanım
```python
from good_engine import GameEngine, Scene, GameObject, ComponentType

# Motor oluştur
engine = GameEngine("PythonGame", 800, 600)

# Sahne oluştur
scene = Scene("MainScene")

# Nesne oluştur
player = GameObject("Player", scene)
player.set_position(100, 200, 0)
player.add_sprite("assets/player.png")
player.add_rigidbody(mass=1.0)

print("Python bridge working!")
```

---

## CMake Seçenekleri

```bash
# Platform seçimi
-DANDROID=ON                    # Android build
-DDESKTOP=ON                    # Desktop build (varsayılan)

# Optimizasyon
-DCMAKE_BUILD_TYPE=Debug        # Debug (slower, bigger)
-DCMAKE_BUILD_TYPE=Release      # Release (optimized)

# Ek özellikler
-DENABLE_PHYSICS=ON             # Physics engine (varsayılan: ON)
-DENABLE_GRAPHICS=ON            # Graphics (varsayılan: ON)
-DENABLE_PLUGINS=ON             # Plugin system (varsayılan: ON)
```

---

## Sorun Giderme

### Sorun: CMake bulunamıyor
**Çözüm:**
```bash
# Kurma
sudo apt-get install cmake

# Sürümü kontrol et
cmake --version   # 3.16+ olmalı
```

### Sorun: C compiler bulunamıyor
**Çözüm:**
```bash
# Linux
sudo apt-get install build-essential

# macOS
xcode-select --install

# Windows: Visual Studio veya MinGW
```

### Sorun: Python bridge libgood_engine.so bulamıyor
**Çözüm:**
```bash
# Motor build et
cd build
cmake ..
make

# Python path'ini güncelle
export LD_LIBRARY_PATH=../../build:$LD_LIBRARY_PATH

# Veya symlink oluştur
ln -s ../../build/libgood_engine.so ./libgood_engine.so
```

### Sorun: Android NDK compile hatası
**Çözüm:**
```bash
# CMake toolchain dosyasını kontrol et
file $ANDROID_NDK/build/cmake/android.cmake

# Doğru ABI seçin
# arm64-v8a: 64-bit ARM
# armeabi-v7a: 32-bit ARM
# x86: Intel 32-bit
# x86_64: Intel 64-bit
```

---

## Build Çıktıları

### Başarılı Linux Build
```
[100%] Built target good_engine_test
Test executable: ./good_engine_test
Library: ./libgood_engine.so
```

### Başarılı Android Build
```
libgood_engine.so (NDK native library)
Install path: build-android/lib
```

---

## Yükleme & Test

### Motor test et
```bash
cd build
./good_engine_test
```

**Beklenen çıktı:**
```
╔════════════════════════════════════════════╗
║     Good Engine - Stage 1 Test Suite      ║
║              v0.1.0-alpha                 ║
║     GNU General Public License v3.0       ║
╚════════════════════════════════════════════╝

[TEST 1] Engine Creation
✓ Engine created successfully

[TEST 2] Scene Creation
✓ Scene created successfully

... (diğer testler)
```

---

## Sonraki Adımlar

1. **API Referansı**: `docs/API.md` okuyun
2. **Python Scripting**: `scripting/python/good_engine.py` örneğini inceleyin
3. **Stage 2**: Physics engine integasyonunu bekleyin

---

**Son Güncelleme:** Nisan 2026  
**Sürüm:** 0.1.0-alpha  
**Lisans:** GNU General Public License v3.0
