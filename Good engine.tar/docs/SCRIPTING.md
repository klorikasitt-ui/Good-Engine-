# Good Engine - Python Scripting Rehberi

## Giriş

Good Engine Python bridge'i, C motorunun güçlü özelliklerine Python programcılarının rahatlığı ile erişimi sağlar. ctypes kullanılarak sağlanan bu bağlantı, düşük seviyeli sistem erişimi olmadan yüksek performanslı oyunlar geliştirmenize olanak tanır.

---

## Başlangıç

### Kurulum

```bash
# Önce motoru build et
cd build
cmake ..
make

# Python kütüphanesini kopyala
cp libgood_engine.so ../scripting/python/

# Python dosyasını test et
cd ../scripting/python
python3 good_engine.py
```

### İlk Script

```python
from good_engine import GameEngine, Scene, GameObject

# Motor oluştur
engine = GameEngine("MyPyGame", 800, 600)

# Sahne ve nesne oluştur
scene = Scene("MainScene")
player = GameObject("Player", scene)

# Oyuncu ekle
player.set_position(100, 200, 0)
player.add_sprite("assets/player.png")

print("Python oyun başlatıldı!")
```

---

## Temel Konseptler

### GameEngine

Motor ana sınıfıdır. Oyunun tüm yaşam döngüsünü yönetir.

```python
engine = GameEngine("oyunadı", width=1280, height=720)
engine.set_target_fps(60)
```

### Scene

Sahneler oyun dünyasının mantıksal bölümleridir. Her sahne kendi GameObjects'ini içerir.

```python
scene = Scene("Level1")
scene.load()   # Sahneyi etkinleştir
scene.unload() # Sahneyi kapat
```

### GameObject

Oyunun nesneleridir (oyuncu, düşman, platform, vb.).

```python
player = GameObject("Player", scene)
enemy = GameObject("Enemy", scene)
platform = GameObject("Platform", scene)
```

### Components

GameObjects, components aracılığıyla davranış kazanır:
- **Transform**: Konum, rotasyon, ölçek
- **Sprite**: Görünüm
- **Rigidbody**: Fizik (kütle, hız)
- **Collider**: Çarpışma (şekil, tetikleyici)

---

## GameObject Oluşturma & Yönetimi

### Basit Nesne Oluşturma

```python
# Sahne olmadan
obj = GameObject("MyObject")

# Sahneye ekle
obj = GameObject("MyObject", scene)

# Sahne içinde kullan
scene.add_object(obj)
```

### Konumlandırma

```python
player.set_position(100, 200, 0)  # X, Y, Z

trans = player.get_transform()
print(trans.position)  # (100, 200, 0)
```

### Rotasyon ve Ölçek

```python
player.set_rotation(0, 0, 45)    # 45 derece Z ekseninde
player.set_scale(2, 2, 1)         # 2x büyütü
```

### Aktivasyon

```python
player.set_active(True)   # Göster ve etkinleştir
player.set_active(False)  # Gizle ve devre dışı bırak
```

---

## Sprite Oluşturma

### Sprite Ekle

```python
player.add_sprite("assets/player.png")
enemy.add_sprite("assets/enemy.png")
```

### Katman Düzeni (Rendering Order)

```python
background.add_sprite("assets/bg.png")
background.set_sprite_layer(0)      # Arka plan

player.add_sprite("assets/player.png")
player.set_sprite_layer(1)          # Ortada

foreground.add_sprite("assets/fg.png")
foreground.set_sprite_layer(2)      # Ön plan
```

---

## Fizik Sistemi

### Rigidbody (Dinamik Fizik)

```python
# Oyuncuya fizik ekle
player.add_rigidbody(mass=1.0)

# Hız ayarla
player.set_rigidbody_velocity(10.0, 0.0)  # Sağa doğru hareket

# Yerçekimi ölçeği
player.set_rigidbody_gravity_scale(1.0)   # Normal yerçekimi
player.set_rigidbody_gravity_scale(0.0)   # Yerçekimi yok
```

### Collider (Çarpışma)

```python
from good_engine import ColliderShape

# Kutu şeklinde collider
player.add_collider(ColliderShape.BOX)
player.set_collider_size(64, 64)

# Daire şeklinde collider
ball.add_collider(ColliderShape.CIRCLE)
ball.set_collider_size(32, 32)

# Tetikleyici collider (çarpışma olmaz, tetikler)
trigger_zone.add_collider(ColliderShape.BOX)
trigger_zone.set_collider_trigger(True)
```

---

## Tam Örnek: Basit Platform Oyunu

```python
from good_engine import GameEngine, Scene, GameObject, ColliderShape, LogLevel

# Setup
engine = GameEngine("PlatformerDemo", 800, 600)
engine.set_target_fps(60)

scene = Scene("Level1")

# Oyuncu oluştur
player = GameObject("Player", scene)
player.set_position(400, 300, 0)
player.add_sprite("assets/player.png")
player.add_rigidbody(mass=1.0)
player.add_collider(ColliderShape.BOX)
player.set_collider_size(32, 64)

# Platform oluştur
platform = GameObject("Platform", scene)
platform.set_position(400, 500, 0)
platform.add_sprite("assets/platform.png")
platform.add_collider(ColliderShape.BOX)
platform.set_collider_size(200, 20)
platform.add_rigidbody(mass=0.0)  # Sabit platform

# Düşman oluştur
enemy = GameObject("Enemy", scene)
enemy.set_position(600, 200, 0)
enemy.add_sprite("assets/enemy.png")
enemy.add_rigidbody(mass=1.0)
enemy.add_collider(ColliderShape.BOX)
enemy.set_collider_size(32, 32)

# Bilgi mesajı
from good_engine import log
log(LogLevel.INFO, "Oyun başladı!")

print("Scene objects:", len(scene._objects))
print("Oyun hazır!")
```

---

## Logging

### Log Mesajları

```python
from good_engine import log, LogLevel

log(LogLevel.DEBUG, "Debug mesajı")
log(LogLevel.INFO, "Bilgi mesajı")
log(LogLevel.WARNING, "Uyarı mesajı")
log(LogLevel.ERROR, "Hata mesajı")

# Parametrelerle
log(LogLevel.INFO, f"Oyuncu konumu: {player_x}, {player_y}")
```

### Bellek İstatistikleri

```python
from good_engine import print_memory_stats

print_memory_stats()  # Bellek kullanımını göster
```

---

## İleri Teknikler

### Nesne Hiyerarşisi

```python
# Silah, oyuncunun çocuğu olsun
weapon = GameObject("Weapon", scene)
player.set_parent(weapon)  # weapon, player ile birlikte hareket eder
```

### Dinamik Nesne Oluşturma

```python
def spawn_enemy(scene, x, y):
    enemy = GameObject(f"Enemy_{x}_{y}", scene)
    enemy.set_position(x, y, 0)
    enemy.add_sprite("assets/enemy.png")
    enemy.add_rigidbody(mass=1.0)
    enemy.add_collider(ColliderShape.BOX)
    return enemy

# 5 düşman oluştur
for i in range(5):
    spawn_enemy(scene, 100 + i * 150, 200)
```

### Fizik Simülasyonu

```python
# Platform (sabit)
platform.add_rigidbody(mass=0.0)  # Kütle = 0 = sabit

# Top (düşme)
ball.add_rigidbody(mass=0.5)
ball.set_rigidbody_gravity_scale(1.0)

# Füze (yukarı)
rocket.add_rigidbody(mass=2.0)
rocket.set_rigidbody_velocity(0, -100)  # Yukarı hızlı
rocket.set_rigidbody_gravity_scale(0.2)  # Az yerçekimi
```

---

## Best Practices

### 1. Isimlendirme
```python
# İyi
player = GameObject("Player", scene)
enemy_01 = GameObject("Enemy_01", scene)

# Kötü
obj1 = GameObject("obj", scene)
x = GameObject("a", scene)
```

### 2. Organizasyon
```python
# Tüm nesneleri bir yerde oluştur
def create_level(scene):
    player = GameObject("Player", scene)
    # ...
    return player

# Sonra kullan
player = create_level(scene)
```

### 3. Kaynak Yönetimi
```python
# Sahneleri temizle
scene.unload()
# Motor kapatılırken temizleme otomatik olur
```

### 4. Hata Yönetimi
```python
try:
    player = GameObject("Player", scene)
    player.add_sprite("assets/player.png")
except Exception as e:
    log(LogLevel.ERROR, f"Oyuncu oluşturulamadı: {e}")
```

---

## Debugging

### Konsolda Bilgi Yazdır

```python
print(f"Oyuncu: {player.name}")
print(f"Konum: {player.get_transform().position}")
print(f"Sahnedeki nesneler: {len(scene._objects)}")
```

### Verbose Logging

```python
# Motor detaylı log yazdırsın
log(LogLevel.DEBUG, "Oyuncu spriteini yükledi")
log(LogLevel.DEBUG, f"Transform: x={trans.x}, y={trans.y}")
```

---

## Sınırlamalar & Bilinen Sorunlar

- Python bridge şu anda tek thread destekler
- Gerçek zamanlı rendering henüz yapılmıyor (Stage 2'de)
- Ses sistemi Stage 2'de eklenecek

---

## Sonraki Adımlar

1. **C API Öğren**: `docs/API.md` okuyun
2. **Örnekleri İnceyin**: `scripting/python/` klasöründe
3. **Projenize Katkıda Bulunun**: GitHub'da PR açın

---

**Son Güncelleme:** Nisan 2026  
**Sürüm:** 0.1.0-alpha  
**Lisans:** GNU General Public License v3.0
