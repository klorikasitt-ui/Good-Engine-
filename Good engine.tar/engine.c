/*
 * Good Engine - Engine Implementation
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include "good_engine.h"
#include "memory_manager.h"

int main(int argc, char *argv[]) {
    ge_log(GE_LOG_INFO, "============================================");
    ge_log(GE_LOG_INFO, "Good Engine v0.1.0 - Stage 1 Foundation");
    ge_log(GE_LOG_INFO, "GNU General Public License v3.0");
    ge_log(GE_LOG_INFO, "============================================");
    
    /* Create engine */
    GameEngine *engine = ge_create_engine("Good Engine", 1280, 720);
    if (!engine) {
        ge_log(GE_LOG_ERROR, "Failed to create engine!");
        return 1;
    }
    
    /* Create scene */
    Scene *scene = ge_create_scene("MainScene");
    if (!scene) {
        ge_log(GE_LOG_ERROR, "Failed to create scene!");
        ge_destroy_engine(engine);
        return 1;
    }
    
    /* Create game object */
    GameObject *player = ge_create_object("Player", scene);
    if (!player) {
        ge_log(GE_LOG_ERROR, "Failed to create game object!");
        ge_destroy_scene(scene);
        ge_destroy_engine(engine);
        return 1;
    }
    
    /* Add components */
    ge_set_position(player, 100.0f, 200.0f, 0.0f);
    ge_add_sprite(player, "assets/player.png");
    ge_add_rigidbody(player, 1.0f);
    Collider *col = ge_add_collider(player, COLLIDER_BOX);
    ge_set_collider_size(player, 64.0f, 64.0f);
    
    ge_log(GE_LOG_INFO, "Scene setup complete!");
    ge_log(GE_LOG_INFO, "Game objects in scene: %zu", scene->objects_count);
    
    /* Display memory stats */
    ge_memory_stats();
    
    ge_log(GE_LOG_INFO, "Engine initialization successful!");
    ge_log(GE_LOG_INFO, "Stage 1 foundation ready for expansion.");
    
    /* Cleanup */
    ge_destroy_scene(scene);
    ge_destroy_engine(engine);
    
    ge_memory_stats();
    ge_log(GE_LOG_INFO, "Good Engine shutdown complete.");
    
    return 0;
}
