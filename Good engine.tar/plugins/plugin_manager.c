/*
 * Good Engine - Plugin Manager
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_plugin_manager_init() {
    printf("[INFO] Plugin Manager initialized\n");
}

void ge_plugin_manager_cleanup() {
    printf("[INFO] Plugin Manager cleaned up\n");
}
