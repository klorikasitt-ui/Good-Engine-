/*
 * Good Engine - Plugin Loader
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_plugin_loader_init() {
    printf("[INFO] Plugin Loader initialized\n");
}

void ge_plugin_loader_cleanup() {
    printf("[INFO] Plugin Loader cleaned up\n");
}
