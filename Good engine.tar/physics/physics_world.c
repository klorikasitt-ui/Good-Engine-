/*
 * Good Engine - Physics World
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_physics_world_init() {
    printf("[INFO] Physics World initialized\n");
}

void ge_physics_world_cleanup() {
    printf("[INFO] Physics World cleaned up\n");
}
