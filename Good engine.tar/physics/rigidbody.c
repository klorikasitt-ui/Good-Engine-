/*
 * Good Engine - Rigidbody Physics
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_rigidbody_init() {
    printf("[INFO] Rigidbody system initialized\n");
}
