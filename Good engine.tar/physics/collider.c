/*
 * Good Engine - Collider
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_collider_init() {
    printf("[INFO] Collider system initialized\n");
}
