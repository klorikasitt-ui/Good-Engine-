# Katkıda Bulunma Rehberi

Good Engine'e katkıda bulunmak istediğiniz için teşekkürler! 🎉

Bu rehber, projeyi geliştirmekte ve katkıda bulunmakta size yardımcı olacak.

---

## İçindekiler

1. [Başlangıç](#başlangıç)
2. [Geliştirme Ortamı Kurulumu](#geliştirme-ortamı-kurulumu)
3. [Kod Yazma Kuralları](#kod-yazma-kuralları)
4. [Pull Request Süreci](#pull-request-süreci)
5. [Bug Raporlama](#bug-raporlama)
6. [Özellik İsteği](#özellik-isteği)
7. [Dokümantasyon](#dokümantasyon)

---

## Başlangıç

### Depoyu Fork Et

```bash
# GitHub'da fork tuşuna tıkla
# Ardından:
git clone https://github.com/YOUR_USERNAME/goodengine.git
cd "Good engine"
git remote add upstream https://github.com/goodengine/goodengine.git
```

### İlk Kurulum

```bash
# Gerekli araçları kur (bkz. docs/BUILD.md)
mkdir build
cd build
cmake ..
make
./good_engine_test  # Test et
```

---

## Geliştirme Ortamı Kurulumu

### Linux (Ubuntu/Debian)

```bash
# Gerekli paketleri kur
sudo apt-get update
sudo apt-get install -y \
    build-essential \
    cmake \
    git \
    python3 \
    python3-dev \
    clang-format

# Build yap
cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug
make -j$(nproc)
```

### macOS

```bash
# Xcode ve Homebrew paketleri
xcode-select --install
brew install cmake python3 clang-format

# Build
cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug
make -j$(sysctl -n hw.logicalcpu)
```

### Windows

```bash
# Visual Studio 2019+ veya MinGW yükleyin
# CMake yükleyin
# Ardından:
mkdir build
cd build
cmake ..
msbuild Good_Engine.sln
```

---

## Kod Yazma Kuralları

### C Kodu Stili

```c
/*
 * Good Engine - [Bileşen Adı]
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include "header.h"
#include <stdlib.h>

/* Makrolar UPPERCASE */
#define MAX_OBJECTS 1000

/* Type'lar PascalCase */
typedef struct {
    int value;
    char *name;
} MyStruct;

/* Fonksiyonlar snake_case, ge_ prefix'i ile */
void ge_my_function() {
    /* Gövde */
}

/* İnline yorum açıklamaları */
int result = calculate();  /* Sonuç */

/* Blok yorumları detaylı açıklamalar için */
/*
 * Bu fonksiyon karmaşık bir görev yapar.
 * Parametreler:
 * - param1: Açıklama
 * - param2: Açıklama
 */
void ge_complex_function(int param1, int param2) {
    /* Kod */
}
```

### Python Kodu Stili

```python
"""
Good Engine - Python Bridge
Copyright (C) 2026 Good Engine Contributors
GNU General Public License v3.0
"""

import sys
from typing import Optional, List

# Sınıflar PascalCase
class GameEngine:
    """Motor sınıfı."""
    
    def __init__(self, name: str, width: int = 1280):
        """
        Başlat.
        
        Args:
            name: Motor adı
            width: Ekran genişliği
        """
        self.name = name
        self.width = width
    
    def run(self) -> None:
        """Motoru çalıştır."""
        pass

# Fonksiyonlar snake_case
def create_object(name: str) -> GameEngine:
    """Nesne oluştur."""
    return GameEngine(name)
```

### Formatı Kontrol Et

```bash
# C kodunu formatla
clang-format -i src/*.c src/*.h

# Python kodunu formatla
black scripting/python/*.py
```

---

## Pull Request Süreci

### 1. Feature Branch Oluştur

```bash
git checkout -b feature/my-feature
```

**Branch adı kuralı:**
- `feature/description` - Yeni özellik
- `bugfix/description` - Bug düzeltme
- `docs/description` - Dokümantasyon
- `refactor/description` - Kod iyileştirmesi

### 2. Kod Yazma & Test

```bash
# Kod yaz
vim src/my_feature.c

# Build et
cd build
cmake ..
make -j$(nproc)

# Test et
./good_engine_test

# Python bridge test
cd ../scripting/python
python3 good_engine.py
```

### 3. Commit

```bash
# Değişiklikleri stage et
git add .

# İyi bir commit mesajı yazı
git commit -m "Add new feature: description"

# Commit kuralları:
# - İmperatif ton kullan ("Add" değil "Added")
# - İlk satır 50 karakterden kısa
# - Detaylı açıklama boş satırdan sonra (72 char)
# - Tip belirt: [FEATURE], [BUGFIX], [DOCS], [REFACTOR]
```

**Örnek commit:**
```
[FEATURE] Add GameObject parent-child hierarchy

- Implement ge_set_object_parent() function
- Update GameObject structure with parent/children pointers
- Add tests for hierarchy system
- Update documentation
```

### 4. Push & Pull Request

```bash
# Kendi fork'una push et
git push origin feature/my-feature

# GitHub'da PR aç
# Title: [FEATURE] Description
# Body: Detaylı açıklama yazı
```

**PR Şablonu:**

```markdown
## Açıklama
Bu PR'ın ne yaptığını açıkla.

## Değişiklikler
- Değişiklik 1
- Değişiklik 2

## Test Sonuçları
- [ ] Kod derlendiği kontrol et
- [ ] Testler geçti
- [ ] Python bridge'i test ettim
- [ ] Dokümantasyonu güncelledim

## İlgili Issues
Closes #123
```

### 5. Review Bekle

Kod maintainers tarafından gözden geçirilecek. İsteğe göre değişiklik yapabilirsin.

---

## Bug Raporlama

### Issue Template

```markdown
## Açıklama
Bug hakkında kısa açıklama.

## Adımlar (Reproduction)
1. Adım 1
2. Adım 2
3. Adım 3

## Beklenen Davranış
Ne olması gerekiyordu?

## Gerçek Davranış
Ne oldu?

## Sistem Bilgisi
- OS: Linux Ubuntu 20.04
- Derleyici: GCC 9.4.0
- CMake Sürümü: 3.16
- Python: 3.8.10

## Hata Mesajı
```
[Hata çıktısı buraya]
```

## Dosyalar
[Varsa problemi gösteren kod/dosya ekle]
```

---

## Özellik İsteği

### Issue Template

```markdown
## Açıklama
Yeni özellik hakkında açıklama.

## Neden Gerekli?
Neden bu özellik faydalı olur?

## Önerilen Çözüm
Nasıl uygulanabilir?

## Alternatifler
Başka seçenekler var mı?

## Ek Bağlam
İlgili linkler, referanslar, vb.
```

---

## Dokümantasyon

### Yeni Fonksiyon Dokümante Et

**C Kodu:**
```c
/**
 * Create a new game object
 * 
 * @param name - Object name (max 256 chars)
 * @param scene - Target scene (can be NULL)
 * @return GameObject pointer on success, NULL on failure
 * 
 * @example
 *   GameObject *obj = ge_create_object("Player", scene);
 */
GameObject* ge_create_object(const char *name, Scene *scene);
```

**Python Kodu:**
```python
def create_object(name: str, scene: Optional[Scene] = None) -> GameObject:
    """
    Create a new game object.
    
    Args:
        name: Object name (max 256 chars)
        scene: Target scene, optional
    
    Returns:
        GameObject instance
    
    Raises:
        MemoryError: If allocation fails
    
    Example:
        >>> obj = GameObject("Player", scene)
    """
    pass
```

### Dokümantasyon Dosyası Güncelle

Yeni fonksiyon eklediyse:
1. `docs/API.md` - Fonksiyon açıklamasını ekle
2. `docs/SCRIPTING.md` - Python örneğini ekle
3. `STRUCTURE.md` - Dosya yapısını güncelle

---

## Testing

### Birim Test Yazma

```c
// tests/my_test.c
#include "../core/good_engine.h"
#include <assert.h>

void test_create_object() {
    Scene *scene = ge_create_scene("TestScene");
    GameObject *obj = ge_create_object("TestObj", scene);
    
    assert(obj != NULL);
    assert(obj->name != NULL);
    assert(scene->objects_count == 1);
    
    ge_destroy_scene(scene);
    printf("✓ test_create_object passed\n");
}

int main() {
    test_create_object();
    // Diğer testler...
    return 0;
}
```

### Test Çalıştırma

```bash
cd build
make
./good_engine_test
```

---

## Build & Lint Kontrolleri

Pre-commit hook kurulumu:

```bash
# .git/hooks/pre-commit oluştur
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
echo "Running pre-commit checks..."

# Format kontrolü
clang-format --dry-run --Werror src/*.c src/*.h 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ Code formatting issues. Run: clang-format -i src/*.c src/*.h"
    exit 1
fi

# Build testi
cd build
cmake .. > /dev/null 2>&1
make > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "❌ Build failed!"
    exit 1
fi

echo "✓ All checks passed"
exit 0
EOF

chmod +x .git/hooks/pre-commit
```

---

## Lisans

Good Engine GNU General Public License v3.0 ile korunmaktadır.

Katkıda bulunarak:
- Kodunuzun GPL v3 altında lisanslandığını kabul etmişsiniz
- Copyright'ın "Good Engine Contributors"'a ait olmasını kabul etmişsiniz
- Kodunuzu özgürce paylaşabileceğinizi kabul etmişsiniz

---

## Etik Kodlama

Lütfen bu etik kurallarını takip edin:

1. **Saygılı** - Herkesin görüşüne saygı duy
2. **Yapıcı** - Kritik yap ama çözüm sun
3. **Inklusif** - Çeşitliliği destekle
4. **Şeffaf** - Niyetlerini açıkça belirt
5. **Sorumlu** - Yaptığın işin sorumluluğunu al

---

## İletişim

- 🐛 **Hata raporları**: Issues sekmesi
- 💬 **Tartışmalar**: Discussions sekmesi
- 📧 **Özel mesaj**: contact@goodengine.dev
- 🤝 **Kod incelemesi**: PR comments

---

## Başarılı Katkılara Örnek

Harika PR'lar genellikle:
- ✅ Açık, kısa ve net
- ✅ İyi test edilmiş
- ✅ İyi dokümante edilmiş
- ✅ Tek bir soruna odaklanmış
- ✅ Kod stiline uygun

---

## Teşekkürler!

Her katkı, Good Engine'i daha iyi hale getiriyor.
Destek için teşekkürler! 🚀

---

**Son Güncelleme:** Nisan 2026  
**Sürüm:** 0.1.0-alpha  
**Lisans:** GNU General Public License v3.0
