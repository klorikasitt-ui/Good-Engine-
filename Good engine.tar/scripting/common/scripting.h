/*
 * Good Engine - Common Scripting Interface
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#ifndef GE_SCRIPTING_COMMON_H
#define GE_SCRIPTING_COMMON_H

#include <stdint.h>

/* Scripting bridge interface */
typedef int (*ScriptCallback)(void *arg);

typedef struct {
    const char *name;
    const char *version;
    void (*init)(void);
    void (*shutdown)(void);
    ScriptCallback (*load_script)(const char *path);
} ScriptingBackend;

#endif /* GE_SCRIPTING_COMMON_H */
