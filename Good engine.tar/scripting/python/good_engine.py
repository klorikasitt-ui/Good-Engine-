"""
Good Engine - Python Scripting Bridge
Copyright (C) 2026 Good Engine Contributors
GNU General Public License v3.0
"""

import ctypes
from ctypes import c_float, c_int, c_char_p, c_void_p, POINTER, Structure
from enum import IntEnum

# Load the Good Engine shared library
try:
    if hasattr(ctypes, 'WinDLL'):
        ge_lib = ctypes.WinDLL('./libgood_engine.dll')
    else:
        ge_lib = ctypes.CDLL('./libgood_engine.so')
except OSError:
    print("[ERROR] Could not load Good Engine library!")
    print("[INFO] Make sure to build the engine first:")
    print("       mkdir build && cd build && cmake .. && make")
    exit(1)

# ==================== Enumerations ====================

class ComponentType(IntEnum):
    TRANSFORM = 0
    SPRITE = 1
    RIGIDBODY = 2
    COLLIDER = 3
    AUDIO = 4
    LIGHT = 5
    SCRIPT = 6
    CUSTOM = 7

class ColliderShape(IntEnum):
    CIRCLE = 0
    BOX = 1
    POLYGON = 2
    CAPSULE = 3

class LogLevel(IntEnum):
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3

# ==================== Structures ====================

class Transform(Structure):
    _fields_ = [
        ("x", c_float),
        ("y", c_float),
        ("z", c_float),
        ("rx", c_float),
        ("ry", c_float),
        ("rz", c_float),
        ("sx", c_float),
        ("sy", c_float),
        ("sz", c_float),
    ]

class Sprite(Structure):
    _fields_ = [
        ("texture_path", c_char_p),
        ("width", c_int),
        ("height", c_int),
        ("layer", c_float),
    ]

class Rigidbody(Structure):
    _fields_ = [
        ("mass", c_float),
        ("velocity_x", c_float),
        ("velocity_y", c_float),
        ("gravity_scale", c_float),
        ("is_kinematic", ctypes.c_bool),
        ("use_gravity", ctypes.c_bool),
    ]

class Collider(Structure):
    _fields_ = [
        ("shape", c_int),
        ("width", c_float),
        ("height", c_float),
        ("radius", c_float),
        ("is_trigger", ctypes.c_bool),
    ]

# ==================== Function Declarations ====================

# Engine functions
ge_lib.ge_create_engine.argtypes = [c_char_p, c_int, c_int]
ge_lib.ge_create_engine.restype = c_void_p

ge_lib.ge_destroy_engine.argtypes = [c_void_p]
ge_lib.ge_destroy_engine.restype = None

ge_lib.ge_run.argtypes = [c_void_p, c_void_p]
ge_lib.ge_run.restype = None

ge_lib.ge_stop.argtypes = [c_void_p]
ge_lib.ge_stop.restype = None

ge_lib.ge_set_target_fps.argtypes = [c_void_p, c_float]
ge_lib.ge_set_target_fps.restype = None

# Scene functions
ge_lib.ge_create_scene.argtypes = [c_char_p]
ge_lib.ge_create_scene.restype = c_void_p

ge_lib.ge_destroy_scene.argtypes = [c_void_p]
ge_lib.ge_destroy_scene.restype = None

ge_lib.ge_load_scene.argtypes = [c_void_p]
ge_lib.ge_load_scene.restype = None

ge_lib.ge_unload_scene.argtypes = [c_void_p]
ge_lib.ge_unload_scene.restype = None

# GameObject functions
ge_lib.ge_create_object.argtypes = [c_char_p, c_void_p]
ge_lib.ge_create_object.restype = c_void_p

ge_lib.ge_destroy_object.argtypes = [c_void_p]
ge_lib.ge_destroy_object.restype = None

ge_lib.ge_set_object_active.argtypes = [c_void_p, ctypes.c_bool]
ge_lib.ge_set_object_active.restype = None

ge_lib.ge_set_object_parent.argtypes = [c_void_p, c_void_p]
ge_lib.ge_set_object_parent.restype = None

# Component functions
ge_lib.ge_add_component.argtypes = [c_void_p, c_int]
ge_lib.ge_add_component.restype = c_void_p

ge_lib.ge_get_component.argtypes = [c_void_p, c_int]
ge_lib.ge_get_component.restype = c_void_p

ge_lib.ge_remove_component.argtypes = [c_void_p, c_int]
ge_lib.ge_remove_component.restype = None

# Transform operations
ge_lib.ge_get_transform.argtypes = [c_void_p]
ge_lib.ge_get_transform.restype = POINTER(Transform)

ge_lib.ge_set_position.argtypes = [c_void_p, c_float, c_float, c_float]
ge_lib.ge_set_position.restype = None

ge_lib.ge_set_rotation.argtypes = [c_void_p, c_float, c_float, c_float]
ge_lib.ge_set_rotation.restype = None

ge_lib.ge_set_scale.argtypes = [c_void_p, c_float, c_float, c_float]
ge_lib.ge_set_scale.restype = None

# Sprite operations
ge_lib.ge_add_sprite.argtypes = [c_void_p, c_char_p]
ge_lib.ge_add_sprite.restype = POINTER(Sprite)

ge_lib.ge_set_sprite_layer.argtypes = [c_void_p, c_float]
ge_lib.ge_set_sprite_layer.restype = None

# Rigidbody operations
ge_lib.ge_add_rigidbody.argtypes = [c_void_p, c_float]
ge_lib.ge_add_rigidbody.restype = POINTER(Rigidbody)

ge_lib.ge_set_rigidbody_velocity.argtypes = [c_void_p, c_float, c_float]
ge_lib.ge_set_rigidbody_velocity.restype = None

ge_lib.ge_set_rigidbody_gravity_scale.argtypes = [c_void_p, c_float]
ge_lib.ge_set_rigidbody_gravity_scale.restype = None

# Collider operations
ge_lib.ge_add_collider.argtypes = [c_void_p, c_int]
ge_lib.ge_add_collider.restype = POINTER(Collider)

ge_lib.ge_set_collider_size.argtypes = [c_void_p, c_float, c_float]
ge_lib.ge_set_collider_size.restype = None

ge_lib.ge_set_collider_trigger.argtypes = [c_void_p, ctypes.c_bool]
ge_lib.ge_set_collider_trigger.restype = None

# Logging
ge_lib.ge_log.argtypes = [c_int, c_char_p]
ge_lib.ge_log.restype = None

ge_lib.ge_memory_stats.argtypes = []
ge_lib.ge_memory_stats.restype = None

# ==================== Python Wrapper Classes ====================

class Transform:
    """Transform Component wrapper"""
    def __init__(self, c_transform):
        self._c = c_transform
    
    @property
    def position(self):
        return (self._c.contents.x, self._c.contents.y, self._c.contents.z)
    
    @property
    def rotation(self):
        return (self._c.contents.rx, self._c.contents.ry, self._c.contents.rz)
    
    @property
    def scale(self):
        return (self._c.contents.sx, self._c.contents.sy, self._c.contents.sz)

class GameObject:
    """GameObject wrapper"""
    def __init__(self, name, scene=None):
        self._obj = ge_lib.ge_create_object(name.encode(), scene._scene if scene else None)
        self._name = name
        self._scene = scene
    
    def __del__(self):
        if self._obj:
            ge_lib.ge_destroy_object(self._obj)
    
    @property
    def name(self):
        return self._name
    
    def set_active(self, active):
        ge_lib.ge_set_object_active(self._obj, active)
    
    def set_position(self, x, y, z=0):
        ge_lib.ge_set_position(self._obj, c_float(x), c_float(y), c_float(z))
    
    def set_rotation(self, x, y, z):
        ge_lib.ge_set_rotation(self._obj, c_float(x), c_float(y), c_float(z))
    
    def set_scale(self, x, y, z=1):
        ge_lib.ge_set_scale(self._obj, c_float(x), c_float(y), c_float(z))
    
    def get_transform(self):
        trans = ge_lib.ge_get_transform(self._obj)
        return Transform(trans)
    
    def add_sprite(self, texture_path):
        ge_lib.ge_add_sprite(self._obj, texture_path.encode())
    
    def add_rigidbody(self, mass=1.0):
        ge_lib.ge_add_rigidbody(self._obj, c_float(mass))
    
    def add_collider(self, shape=ColliderShape.BOX):
        ge_lib.ge_add_collider(self._obj, c_int(shape))
    
    def set_rigidbody_velocity(self, vx, vy):
        ge_lib.ge_set_rigidbody_velocity(self._obj, c_float(vx), c_float(vy))

class Scene:
    """Scene wrapper"""
    def __init__(self, name):
        self._scene = ge_lib.ge_create_scene(name.encode())
        self._name = name
        self._objects = []
    
    def __del__(self):
        if self._scene:
            ge_lib.ge_destroy_scene(self._scene)
    
    @property
    def name(self):
        return self._name
    
    def add_object(self, obj):
        self._objects.append(obj)
    
    def load(self):
        ge_lib.ge_load_scene(self._scene)
    
    def unload(self):
        ge_lib.ge_unload_scene(self._scene)

class GameEngine:
    """GameEngine wrapper"""
    def __init__(self, name, width=1280, height=720):
        self._engine = ge_lib.ge_create_engine(name.encode(), c_int(width), c_int(height))
        self._name = name
    
    def __del__(self):
        if self._engine:
            ge_lib.ge_destroy_engine(self._engine)
    
    @property
    def name(self):
        return self._name
    
    def set_target_fps(self, fps):
        ge_lib.ge_set_target_fps(self._engine, c_float(fps))
    
    def run(self, scene):
        ge_lib.ge_run(self._engine, scene._scene)
    
    def stop(self):
        ge_lib.ge_stop(self._engine)

# ==================== Utility Functions ====================

def log(level, message):
    """Log a message"""
    ge_lib.ge_log(c_int(level), message.encode())

def print_memory_stats():
    """Print memory statistics"""
    ge_lib.ge_memory_stats()

# ==================== Example Usage ====================

if __name__ == "__main__":
    print("\n" + "="*50)
    print("Good Engine - Python Bridge Example")
    print("="*50 + "\n")
    
    # Create engine
    engine = GameEngine("PyEngine", 800, 600)
    log(LogLevel.INFO, "Python engine created!")
    
    # Create scene
    scene = Scene("MainScene")
    log(LogLevel.INFO, "Scene created!")
    
    # Create game object
    player = GameObject("Player", scene)
    player.set_position(100, 200, 0)
    player.add_sprite("assets/player.png")
    player.add_rigidbody(mass=2.0)
    player.add_collider(ColliderShape.BOX)
    
    log(LogLevel.INFO, "Player object created with components!")
    
    # Get transform
    trans = player.get_transform()
    print(f"Player position: {trans.position}")
    
    print_memory_stats()
    
    print("\n" + "="*50)
    print("Example completed!")
    print("="*50 + "\n")
