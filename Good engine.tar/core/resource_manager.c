/*
 * Good Engine - Resource Manager
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_resource_init() {
    printf("[INFO] Resource Manager initialized\n");
}

void ge_resource_cleanup() {
    printf("[INFO] Resource Manager cleaned up\n");
}
