/*
 * Good Engine - Scene
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

/* Scene implementations are in game_loop.c */
void ge_scene_init() {
    printf("[INFO] Scene system initialized\n");
}
