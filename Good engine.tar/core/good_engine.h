/*
 * Good Engine - Godot-like Android Game Engine
 * Copyright (C) 2026 Good Engine Contributors
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

#ifndef GOOD_ENGINE_H
#define GOOD_ENGINE_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* ==================== Forward Declarations ==================== */
typedef struct GameEngine GameEngine;
typedef struct Scene Scene;
typedef struct GameObject GameObject;
typedef struct Component Component;
typedef struct Transform Transform;
typedef struct Rigidbody Rigidbody;
typedef struct Collider Collider;
typedef struct Sprite Sprite;

/* ==================== Enumerations ==================== */

typedef enum {
    COMPONENT_TRANSFORM,
    COMPONENT_SPRITE,
    COMPONENT_RIGIDBODY,
    COMPONENT_COLLIDER,
    COMPONENT_AUDIO,
    COMPONENT_LIGHT,
    COMPONENT_SCRIPT,
    COMPONENT_CUSTOM
} ComponentType;

typedef enum {
    COLLIDER_CIRCLE,
    COLLIDER_BOX,
    COLLIDER_POLYGON,
    COLLIDER_CAPSULE
} ColliderShape;

/* ==================== Structures ==================== */

/* Transform Component */
typedef struct {
    float x, y, z;          /* Position */
    float rx, ry, rz;       /* Rotation (degrees) */
    float sx, sy, sz;       /* Scale */
} Transform;

/* Sprite Component */
typedef struct {
    char *texture_path;
    uint32_t width, height;
    float layer;
} Sprite;

/* Collider Component */
typedef struct {
    ColliderShape shape;
    float width, height, radius;
    bool is_trigger;
} Collider;

/* Rigidbody Component */
typedef struct {
    float mass;
    float velocity_x, velocity_y;
    float gravity_scale;
    bool is_kinematic;
    bool use_gravity;
} Rigidbody;

/* Component Structure */
typedef struct {
    ComponentType type;
    void *data;
    void (*update)(void *data, float delta_time);
    void (*on_destroy)(void *data);
} Component;

/* GameObject Structure */
typedef struct {
    uint32_t id;
    char *name;
    bool active;
    GameObject *parent;
    GameObject **children;
    size_t children_count;
    Component **components;
    size_t components_count;
    void *user_data;
} GameObject;

/* Scene Structure */
typedef struct {
    char *name;
    GameObject **objects;
    size_t objects_count;
    Transform global_transform;
    bool is_active;
    void *physics_world;
} Scene;

/* Game Engine Main Structure */
typedef struct {
    char *name;
    uint32_t width, height;
    float target_fps;
    bool is_running;
    Scene *current_scene;
    void *graphics_context;
    void *audio_context;
    void *plugin_manager;
    uint64_t frame_count;
    float delta_time;
} GameEngine;

/* ==================== Engine Functions ==================== */

/* Create and manage engine */
GameEngine* ge_create_engine(const char *name, uint32_t width, uint32_t height);
void ge_destroy_engine(GameEngine *engine);
void ge_run(GameEngine *engine, Scene *scene);
void ge_stop(GameEngine *engine);
void ge_set_target_fps(GameEngine *engine, float fps);

/* ==================== Scene Functions ==================== */

/* Create and manage scenes */
Scene* ge_create_scene(const char *name);
void ge_destroy_scene(Scene *scene);
void ge_add_scene_object(Scene *scene, GameObject *object);
void ge_remove_scene_object(Scene *scene, GameObject *object);
void ge_load_scene(Scene *scene);
void ge_unload_scene(Scene *scene);

/* ==================== GameObject Functions ==================== */

/* Create and manage game objects */
GameObject* ge_create_object(const char *name, Scene *scene);
void ge_destroy_object(GameObject *object);
void ge_set_object_active(GameObject *object, bool active);
void ge_set_object_parent(GameObject *child, GameObject *parent);

/* ==================== Component Functions ==================== */

/* Add and manage components */
Component* ge_add_component(GameObject *object, ComponentType type);
Component* ge_get_component(GameObject *object, ComponentType type);
void ge_remove_component(GameObject *object, ComponentType type);

/* Transform operations */
Transform* ge_get_transform(GameObject *object);
void ge_set_position(GameObject *object, float x, float y, float z);
void ge_set_rotation(GameObject *object, float x, float y, float z);
void ge_set_scale(GameObject *object, float x, float y, float z);

/* Sprite operations */
Sprite* ge_add_sprite(GameObject *object, const char *texture_path);
void ge_set_sprite_layer(GameObject *object, float layer);

/* Rigidbody operations */
Rigidbody* ge_add_rigidbody(GameObject *object, float mass);
void ge_set_rigidbody_velocity(GameObject *object, float vx, float vy);
void ge_set_rigidbody_gravity_scale(GameObject *object, float scale);

/* Collider operations */
Collider* ge_add_collider(GameObject *object, ColliderShape shape);
void ge_set_collider_size(GameObject *object, float width, float height);
void ge_set_collider_trigger(GameObject *object, bool is_trigger);

/* ==================== Utility Functions ==================== */

/* Memory and resource management */
void* ge_malloc(size_t size);
void* ge_calloc(size_t count, size_t size);
void* ge_realloc(void *ptr, size_t size);
void ge_free(void *ptr);

/* String utilities */
char* ge_strdup(const char *str);
void ge_strdel(char *str);

/* Logging */
typedef enum {
    GE_LOG_DEBUG,
    GE_LOG_INFO,
    GE_LOG_WARNING,
    GE_LOG_ERROR
} LogLevel;

void ge_log(LogLevel level, const char *format, ...);

#endif /* GOOD_ENGINE_H */
