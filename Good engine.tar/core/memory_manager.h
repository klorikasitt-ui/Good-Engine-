/*
 * Good Engine - Memory Manager Header
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#ifndef GE_MEMORY_MANAGER_H
#define GE_MEMORY_MANAGER_H

#include <stddef.h>

/* Memory allocation functions */
void* ge_malloc(size_t size);
void* ge_calloc(size_t count, size_t size);
void* ge_realloc(void *ptr, size_t size);
void ge_free(void *ptr);

/* String utilities */
char* ge_strdup(const char *str);
void ge_strdel(char *str);

/* Memory statistics */
size_t ge_get_total_allocated();
void ge_memory_stats();

#endif /* GE_MEMORY_MANAGER_H */
