/*
 * Good Engine - Game Engine Implementation
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include "good_engine.h"
#include "memory_manager.h"
#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#ifdef _WIN32
    #include <windows.h>
    #define sleep_ms(ms) Sleep(ms)
#else
    #include <unistd.h>
    #define sleep_ms(ms) usleep(ms * 1000)
#endif

/* ==================== Logging System ==================== */

void ge_log(LogLevel level, const char *format, ...) {
    const char *level_str[] = {
        "[DEBUG]  ",
        "[INFO]   ",
        "[WARN]   ",
        "[ERROR]  "
    };
    
    printf("%s", level_str[level]);
    
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    
    printf("\n");
}

/* ==================== Engine Creation ==================== */

static uint32_t next_object_id = 1;

uint32_t ge_get_next_object_id() {
    return next_object_id++;
}

GameEngine* ge_create_engine(const char *name, uint32_t width, uint32_t height) {
    GameEngine *engine = (GameEngine *)ge_malloc(sizeof(GameEngine));
    
    if (!engine) {
        ge_log(GE_LOG_ERROR, "Failed to create engine");
        return NULL;
    }
    
    engine->name = ge_strdup(name);
    engine->width = width;
    engine->height = height;
    engine->target_fps = 60.0f;
    engine->is_running = false;
    engine->current_scene = NULL;
    engine->graphics_context = NULL;
    engine->audio_context = NULL;
    engine->plugin_manager = NULL;
    engine->frame_count = 0;
    engine->delta_time = 0.0f;
    
    ge_log(GE_LOG_INFO, "Engine created: %s (%dx%d)", name, width, height);
    
    return engine;
}

void ge_destroy_engine(GameEngine *engine) {
    if (!engine) return;
    
    if (engine->current_scene) {
        ge_unload_scene(engine->current_scene);
    }
    
    ge_strdel(engine->name);
    ge_free(engine);
    
    ge_log(GE_LOG_INFO, "Engine destroyed");
}

void ge_set_target_fps(GameEngine *engine, float fps) {
    if (!engine) return;
    engine->target_fps = fps > 0 ? fps : 60.0f;
    ge_log(GE_LOG_DEBUG, "Target FPS set to %.1f", engine->target_fps);
}

/* ==================== Game Loop ==================== */

void ge_run(GameEngine *engine, Scene *scene) {
    if (!engine || !scene) {
        ge_log(GE_LOG_ERROR, "Cannot run engine: invalid parameters");
        return;
    }
    
    engine->current_scene = scene;
    engine->is_running = true;
    
    ge_load_scene(scene);
    ge_log(GE_LOG_INFO, "Starting game loop (Target FPS: %.0f)", engine->target_fps);
    
    float frame_time = 1.0f / engine->target_fps;
    uint64_t last_frame_time = 0;
    
    #ifdef __APPLE__
        #include <mach/mach_time.h>
        mach_timebase_info_data_t timebase;
        mach_timebase_info(&timebase);
    #else
        struct timespec start_time;
        clock_gettime(CLOCK_MONOTONIC, &start_time);
    #endif
    
    while (engine->is_running) {
        /* Calculate delta time */
        #ifdef __APPLE__
            uint64_t current_time = mach_absolute_time();
            if (last_frame_time > 0) {
                engine->delta_time = (float)(current_time - last_frame_time) 
                                    * timebase.numer / (timebase.denom * 1e9f);
            }
            last_frame_time = current_time;
        #else
            struct timespec current_time;
            clock_gettime(CLOCK_MONOTONIC, &current_time);
            
            if (last_frame_time > 0) {
                uint64_t elapsed = (current_time.tv_sec - last_frame_time / 1000000000UL) * 1000000000UL
                                  + current_time.tv_nsec - (last_frame_time % 1000000000UL);
                engine->delta_time = (float)elapsed / 1e9f;
            }
            last_frame_time = current_time.tv_sec * 1000000000UL + current_time.tv_nsec;
        #endif
        
        /* Frame rate limiting */
        if (engine->delta_time < frame_time) {
            float sleep_time = (frame_time - engine->delta_time) * 1000.0f;
            if (sleep_time > 0) {
                sleep_ms((unsigned int)sleep_time);
            }
        }
        
        engine->frame_count++;
    }
    
    ge_unload_scene(scene);
    ge_log(GE_LOG_INFO, "Game loop ended. Frames rendered: %llu", engine->frame_count);
}

void ge_stop(GameEngine *engine) {
    if (engine) {
        engine->is_running = false;
        ge_log(GE_LOG_INFO, "Engine stopping...");
    }
}

/* ==================== Scene Management ==================== */

Scene* ge_create_scene(const char *name) {
    Scene *scene = (Scene *)ge_malloc(sizeof(Scene));
    
    if (!scene) {
        ge_log(GE_LOG_ERROR, "Failed to create scene");
        return NULL;
    }
    
    scene->name = ge_strdup(name);
    scene->objects = NULL;
    scene->objects_count = 0;
    scene->global_transform.x = 0;
    scene->global_transform.y = 0;
    scene->global_transform.z = 0;
    scene->is_active = false;
    scene->physics_world = NULL;
    
    ge_log(GE_LOG_INFO, "Scene created: %s", name);
    
    return scene;
}

void ge_destroy_scene(Scene *scene) {
    if (!scene) return;
    
    for (size_t i = 0; i < scene->objects_count; i++) {
        ge_destroy_object(scene->objects[i]);
    }
    
    ge_free(scene->objects);
    ge_strdel(scene->name);
    ge_free(scene);
    
    ge_log(GE_LOG_INFO, "Scene destroyed");
}

void ge_add_scene_object(Scene *scene, GameObject *object) {
    if (!scene || !object) return;
    
    scene->objects = (GameObject **)ge_realloc(scene->objects, 
                                               sizeof(GameObject *) * (scene->objects_count + 1));
    scene->objects[scene->objects_count] = object;
    scene->objects_count++;
}

void ge_remove_scene_object(Scene *scene, GameObject *object) {
    if (!scene || !object) return;
    
    for (size_t i = 0; i < scene->objects_count; i++) {
        if (scene->objects[i] == object) {
            scene->objects[i] = scene->objects[scene->objects_count - 1];
            scene->objects_count--;
            scene->objects = (GameObject **)ge_realloc(scene->objects,
                                                       sizeof(GameObject *) * scene->objects_count);
            break;
        }
    }
}

void ge_load_scene(Scene *scene) {
    if (!scene) return;
    scene->is_active = true;
    ge_log(GE_LOG_DEBUG, "Scene loaded: %s", scene->name);
}

void ge_unload_scene(Scene *scene) {
    if (!scene) return;
    scene->is_active = false;
    ge_log(GE_LOG_DEBUG, "Scene unloaded: %s", scene->name);
}

/* ==================== GameObject Management ==================== */

GameObject* ge_create_object(const char *name, Scene *scene) {
    GameObject *obj = (GameObject *)ge_malloc(sizeof(GameObject));
    
    if (!obj) {
        ge_log(GE_LOG_ERROR, "Failed to create game object");
        return NULL;
    }
    
    obj->id = ge_get_next_object_id();
    obj->name = ge_strdup(name);
    obj->active = true;
    obj->parent = NULL;
    obj->children = NULL;
    obj->children_count = 0;
    obj->components = NULL;
    obj->components_count = 0;
    obj->user_data = NULL;
    
    if (scene) {
        ge_add_scene_object(scene, obj);
    }
    
    /* Add default Transform component */
    ge_add_component(obj, COMPONENT_TRANSFORM);
    
    ge_log(GE_LOG_DEBUG, "GameObject created: %s (ID: %u)", name, obj->id);
    
    return obj;
}

void ge_destroy_object(GameObject *object) {
    if (!object) return;
    
    for (size_t i = 0; i < object->children_count; i++) {
        ge_destroy_object(object->children[i]);
    }
    ge_free(object->children);
    
    for (size_t i = 0; i < object->components_count; i++) {
        if (object->components[i]->on_destroy) {
            object->components[i]->on_destroy(object->components[i]->data);
        }
        ge_free(object->components[i]);
    }
    ge_free(object->components);
    
    ge_strdel(object->name);
    ge_free(object);
}

void ge_set_object_active(GameObject *object, bool active) {
    if (!object) return;
    object->active = active;
    ge_log(GE_LOG_DEBUG, "GameObject %s set active: %d", object->name, active);
}

void ge_set_object_parent(GameObject *child, GameObject *parent) {
    if (!child) return;
    
    child->parent = parent;
    if (parent) {
        parent->children = (GameObject **)ge_realloc(parent->children,
                                                     sizeof(GameObject *) * (parent->children_count + 1));
        parent->children[parent->children_count] = child;
        parent->children_count++;
        ge_log(GE_LOG_DEBUG, "Set parent: %s -> %s", child->name, parent->name);
    }
}

/* ==================== Component Management ==================== */

Component* ge_add_component(GameObject *object, ComponentType type) {
    if (!object) return NULL;
    
    Component *comp = (Component *)ge_malloc(sizeof(Component));
    comp->type = type;
    comp->data = NULL;
    comp->update = NULL;
    comp->on_destroy = NULL;
    
    /* Initialize component data based on type */
    switch (type) {
        case COMPONENT_TRANSFORM: {
            Transform *transform = (Transform *)ge_malloc(sizeof(Transform));
            transform->x = transform->y = transform->z = 0;
            transform->rx = transform->ry = transform->rz = 0;
            transform->sx = transform->sy = transform->sz = 1;
            comp->data = transform;
            break;
        }
        case COMPONENT_SPRITE: {
            Sprite *sprite = (Sprite *)ge_calloc(1, sizeof(Sprite));
            sprite->width = sprite->height = 100;
            sprite->layer = 0;
            comp->data = sprite;
            break;
        }
        case COMPONENT_RIGIDBODY: {
            Rigidbody *rb = (Rigidbody *)ge_calloc(1, sizeof(Rigidbody));
            rb->mass = 1.0f;
            rb->gravity_scale = 1.0f;
            rb->use_gravity = true;
            comp->data = rb;
            break;
        }
        case COMPONENT_COLLIDER: {
            Collider *col = (Collider *)ge_calloc(1, sizeof(Collider));
            col->shape = COLLIDER_BOX;
            col->width = col->height = 1.0f;
            col->is_trigger = false;
            comp->data = col;
            break;
        }
        default:
            ge_log(GE_LOG_DEBUG, "Component type %d created", type);
    }
    
    object->components = (Component **)ge_realloc(object->components,
                                                   sizeof(Component *) * (object->components_count + 1));
    object->components[object->components_count] = comp;
    object->components_count++;
    
    return comp;
}

Component* ge_get_component(GameObject *object, ComponentType type) {
    if (!object) return NULL;
    
    for (size_t i = 0; i < object->components_count; i++) {
        if (object->components[i]->type == type) {
            return object->components[i];
        }
    }
    
    return NULL;
}

void ge_remove_component(GameObject *object, ComponentType type) {
    if (!object) return;
    
    for (size_t i = 0; i < object->components_count; i++) {
        if (object->components[i]->type == type) {
            if (object->components[i]->on_destroy) {
                object->components[i]->on_destroy(object->components[i]->data);
            }
            ge_free(object->components[i]);
            object->components[i] = object->components[object->components_count - 1];
            object->components_count--;
            break;
        }
    }
}

/* ==================== Transform Operations ==================== */

Transform* ge_get_transform(GameObject *object) {
    if (!object) return NULL;
    Component *comp = ge_get_component(object, COMPONENT_TRANSFORM);
    return comp ? (Transform *)comp->data : NULL;
}

void ge_set_position(GameObject *object, float x, float y, float z) {
    Transform *t = ge_get_transform(object);
    if (t) {
        t->x = x;
        t->y = y;
        t->z = z;
    }
}

void ge_set_rotation(GameObject *object, float x, float y, float z) {
    Transform *t = ge_get_transform(object);
    if (t) {
        t->rx = x;
        t->ry = y;
        t->rz = z;
    }
}

void ge_set_scale(GameObject *object, float x, float y, float z) {
    Transform *t = ge_get_transform(object);
    if (t) {
        t->sx = x;
        t->sy = y;
        t->sz = z;
    }
}

/* ==================== Sprite Operations ==================== */

Sprite* ge_add_sprite(GameObject *object, const char *texture_path) {
    if (!object || !texture_path) return NULL;
    
    Component *comp = ge_add_component(object, COMPONENT_SPRITE);
    if (!comp) return NULL;
    
    Sprite *sprite = (Sprite *)comp->data;
    sprite->texture_path = ge_strdup(texture_path);
    
    ge_log(GE_LOG_DEBUG, "Sprite added to %s: %s", object->name, texture_path);
    
    return sprite;
}

void ge_set_sprite_layer(GameObject *object, float layer) {
    Component *comp = ge_get_component(object, COMPONENT_SPRITE);
    if (comp) {
        Sprite *sprite = (Sprite *)comp->data;
        sprite->layer = layer;
    }
}

/* ==================== Rigidbody Operations ==================== */

Rigidbody* ge_add_rigidbody(GameObject *object, float mass) {
    if (!object) return NULL;
    
    Component *comp = ge_add_component(object, COMPONENT_RIGIDBODY);
    if (!comp) return NULL;
    
    Rigidbody *rb = (Rigidbody *)comp->data;
    rb->mass = mass > 0 ? mass : 1.0f;
    
    ge_log(GE_LOG_DEBUG, "Rigidbody added to %s (mass: %.2f)", object->name, rb->mass);
    
    return rb;
}

void ge_set_rigidbody_velocity(GameObject *object, float vx, float vy) {
    Component *comp = ge_get_component(object, COMPONENT_RIGIDBODY);
    if (comp) {
        Rigidbody *rb = (Rigidbody *)comp->data;
        rb->velocity_x = vx;
        rb->velocity_y = vy;
    }
}

void ge_set_rigidbody_gravity_scale(GameObject *object, float scale) {
    Component *comp = ge_get_component(object, COMPONENT_RIGIDBODY);
    if (comp) {
        Rigidbody *rb = (Rigidbody *)comp->data;
        rb->gravity_scale = scale;
    }
}

/* ==================== Collider Operations ==================== */

Collider* ge_add_collider(GameObject *object, ColliderShape shape) {
    if (!object) return NULL;
    
    Component *comp = ge_add_component(object, COMPONENT_COLLIDER);
    if (!comp) return NULL;
    
    Collider *col = (Collider *)comp->data;
    col->shape = shape;
    
    const char *shape_names[] = {"Circle", "Box", "Polygon", "Capsule"};
    ge_log(GE_LOG_DEBUG, "Collider added to %s: %s", object->name, shape_names[shape]);
    
    return col;
}

void ge_set_collider_size(GameObject *object, float width, float height) {
    Component *comp = ge_get_component(object, COMPONENT_COLLIDER);
    if (comp) {
        Collider *col = (Collider *)comp->data;
        col->width = width;
        col->height = height;
    }
}

void ge_set_collider_trigger(GameObject *object, bool is_trigger) {
    Component *comp = ge_get_component(object, COMPONENT_COLLIDER);
    if (comp) {
        Collider *col = (Collider *)comp->data;
        col->is_trigger = is_trigger;
    }
}
