/*
 * Good Engine - Component
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

/* Component implementations are in game_loop.c */
void ge_component_init() {
    printf("[INFO] Component system initialized\n");
}
