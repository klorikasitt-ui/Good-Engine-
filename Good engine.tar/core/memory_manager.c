/*
 * Good Engine - Memory Manager
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include "memory_manager.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

typedef struct {
    void *ptr;
    size_t size;
    const char *file;
    int line;
} MemoryBlock;

#define MAX_ALLOCATIONS 10000

static MemoryBlock memory_blocks[MAX_ALLOCATIONS];
static size_t memory_block_count = 0;
static size_t total_allocated = 0;

void* ge_malloc(size_t size) {
    if (size == 0) return NULL;
    
    void *ptr = malloc(size);
    if (!ptr) {
        fprintf(stderr, "[ERROR] Memory allocation failed: %zu bytes\n", size);
        return NULL;
    }
    
    if (memory_block_count < MAX_ALLOCATIONS) {
        memory_blocks[memory_block_count].ptr = ptr;
        memory_blocks[memory_block_count].size = size;
        memory_blocks[memory_block_count].file = "unknown";
        memory_blocks[memory_block_count].line = 0;
        memory_block_count++;
    }
    
    total_allocated += size;
    return ptr;
}

void* ge_calloc(size_t count, size_t size) {
    if (count == 0 || size == 0) return NULL;
    
    void *ptr = calloc(count, size);
    if (!ptr) {
        fprintf(stderr, "[ERROR] Memory allocation failed: %zu x %zu bytes\n", count, size);
        return NULL;
    }
    
    if (memory_block_count < MAX_ALLOCATIONS) {
        memory_blocks[memory_block_count].ptr = ptr;
        memory_blocks[memory_block_count].size = count * size;
        memory_blocks[memory_block_count].file = "unknown";
        memory_blocks[memory_block_count].line = 0;
        memory_block_count++;
    }
    
    total_allocated += (count * size);
    return ptr;
}

void* ge_realloc(void *ptr, size_t size) {
    if (size == 0) {
        if (ptr) ge_free(ptr);
        return NULL;
    }
    
    void *new_ptr = realloc(ptr, size);
    if (!new_ptr) {
        fprintf(stderr, "[ERROR] Memory reallocation failed: %zu bytes\n", size);
        return NULL;
    }
    
    /* Update memory block tracking */
    for (size_t i = 0; i < memory_block_count; i++) {
        if (memory_blocks[i].ptr == ptr) {
            memory_blocks[i].ptr = new_ptr;
            memory_blocks[i].size = size;
            break;
        }
    }
    
    return new_ptr;
}

void ge_free(void *ptr) {
    if (!ptr) return;
    
    /* Remove from tracking */
    for (size_t i = 0; i < memory_block_count; i++) {
        if (memory_blocks[i].ptr == ptr) {
            total_allocated -= memory_blocks[i].size;
            memory_blocks[i] = memory_blocks[memory_block_count - 1];
            memory_block_count--;
            break;
        }
    }
    
    free(ptr);
}

char* ge_strdup(const char *str) {
    if (!str) return NULL;
    
    size_t len = strlen(str) + 1;
    char *copy = (char *)ge_malloc(len);
    if (copy) {
        strcpy(copy, str);
    }
    return copy;
}

void ge_strdel(char *str) {
    ge_free(str);
}

size_t ge_get_total_allocated() {
    return total_allocated;
}

void ge_memory_stats() {
    printf("\n========== Good Engine Memory Stats ==========\n");
    printf("Total Allocated: %zu bytes (%.2f MB)\n", 
           total_allocated, total_allocated / (1024.0 * 1024.0));
    printf("Active Blocks: %zu / %d\n", memory_block_count, MAX_ALLOCATIONS);
    printf("=============================================\n\n");
}
