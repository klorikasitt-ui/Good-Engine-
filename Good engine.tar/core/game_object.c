/*
 * Good Engine - Game Object
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

/* GameObject implementations are in game_loop.c */
void ge_object_init() {
    printf("[INFO] GameObject system initialized\n");
}
