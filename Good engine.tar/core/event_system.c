/*
 * Good Engine - Event System
 * Copyright (C) 2026 Good Engine Contributors
 * GNU General Public License v3.0
 */

#include <stdio.h>

void ge_event_system_init() {
    printf("[INFO] Event System initialized\n");
}

void ge_event_system_cleanup() {
    printf("[INFO] Event System cleaned up\n");
}
